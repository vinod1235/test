<?php
$cfgServer='locahost';
$cfgPort='8080';
$username='admin';
$password='admin';
$sever_session=new ServerConnection($cfgPort,$cfgServer,$username=null,$password=null);
//1.telnet to server
$sever_session->telnet();
//2.ssh to sever_session
$sever_session->ssh();
//3.Check disk usage
$path='C:';
$sever_session->checkdiskusage($path);
//4.inode usage
$sever_session->checkinodeusage($path);
//5.get list of files from path
$sever_session->list_files($path);

//5.copy files to remote server
//a.ftp
$sever_session->ftpuploadFile($source,$destination);
//b.scp
$sever_session->scp_upload($source,$destination);
//a.sftp
$sever_session->sftp_upload($source,$destination);


Class ServerConnection{
	public $cfgPort    = "8080";                //port, 22 if SSH
    public $cfgTimeOut = "5";
    public $cfgServer ="localhost";
    public $username ;
    public $password ;
    public $path ;
	public $connectionId;
	public $message;

	public function __construct($cfgPort,$cfgServer,$username=null,$password=null){
		$this->cfgPort=$cfgPort;
		$this->cfgServer=$cfgServer;
		$this->username=$username;
		$this->password=$password;
		$this->path=$path;
	
	}
   public function checkinodeusage($path='/'){
	return fileinode($path);
  }

	public function checkdiskusage($path='/'){
		$total_size=disk_total_space($path);
		$free_size= disk_free_space($path);
         $disk_usage=$total_size-$free_size;
	 	return  $disk_usage;
	}

	public function list_files($path='/'){
		$files=scandir($path);
		return  $files;
	}

	public function ssh(){
	 $connection = ssh2_connect('$this->cfgServer', $this->cfgPort);
     ssh2_auth_password($connection, $this->username, $this->password);
     $stream = ssh2_exec($connection, '/usr/local/bin/php -i');
	return  $stream;
	}

	public function telnet(){
		$f=fsockopen("$this->cfgServer",$this->cfgPort,$this->cfgTimeOut);
		if (!$f)
		{
		return true;
		}
		else
		{
		return false;
		}
}


//ftp connection
public function ftpconnect ($isPassive = false)
{            $server=$this->cfgServer;
			$ftpUser=$this->username; 
			$ftpPassword=$this->password; 
 
    // *** Set up basic connection
    $this->connectionId = ftp_connect($server);
 
    // *** Login with username and password
    $loginResult = ftp_login($this->connectionId, $ftpUser, $ftpPassword);
 
    // *** Sets passive mode on/off (default off)
    ftp_pasv($this->connectionId, $isPassive);
 
    // *** Check connection
    if ((!$this->connectionId) || (!$loginResult)) {
        $this->logMessage('FTP connection has failed!');
        $this->logMessage('Attempted to connect to ' . $server . ' for user ' . $ftpUser, true);
        return false;
    } else {
        $this->logMessage('Connected to ' . $server . ', for user ' . $ftpUser);
        $this->loginOk = true;
        return true;
    }
}


public function ftpuploadFile ($fileFrom, $fileTo)
{
    // *** Set the transfer mode
    $asciiArray = array('txt', 'csv');
    $extension = end(explode('.', $fileFrom));
    if (in_array($extension, $asciiArray)) {
        $mode = FTP_ASCII;      
    } else {
        $mode = FTP_BINARY;
    }
 
    // *** Upload the file
    $upload = ftp_put($this->connectionId, $fileTo, $fileFrom, $mode);
 
    // *** Check upload status
    if (!$upload) {
 
            $this->logMessage('FTP upload has failed!');
            return false;
 
        } else {
            $this->logMessage('Uploaded "' . $fileFrom . '" as "' . $fileTo);
            return true;
        }
}



public function logMessage($mesage){
	$this->message=$mesage;
}

///sftp upload file

public function scp_upload($souce_file,$destination){
$connection = ssh2_connect($$this->cfgServer, $$this->cfgPort);

if(ssh2_auth_password($connection, $serverUser, $serverPassword)){
    echo "connected\n";
    ssh2_scp_send($connection, "/path/to/local/".$file, "/path/to/remote/".$file);
    echo "done\n";
} else {
    echo "connection failed\n";
}

}
public function sftp_upload($souce_file,$destination){
$connection = ssh2_connect($$this->cfgServer, $$this->cfgPort);

if(ssh2_auth_password($connection, $serverUser, $serverPassword)){
    echo "connected\n";
	$sftp = ssh2_sftp($connection);
     ssh2_scp_send($connection, "/path/to/local/".$file, "/path/to/remote/".$file);
    echo "done\n";
} else {
    echo "connection failed\n";
}

}

}
?>