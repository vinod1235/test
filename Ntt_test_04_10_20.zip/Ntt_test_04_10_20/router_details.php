<?php 
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);
require_once "./api/config/config.php";

  $databaseService = new DatabaseService();
  $conn = $databaseService->getConnection();
if (isset($_GET['checkloopback']) && $_GET['checkloopback']='check') {
	$loopback=isset($_REQUEST['loopback'][0])?$_REQUEST['loopback'][0]:'';
	$status= $databaseService->isValidIP($loopback);
	if($status){echo 'true';}else{echo 'false';}
	exit();
}
if (isset($_GET['action']) && $_GET['action']='search_listing') {
	
		$query='';
		if($query==''){
			$query=' 1=1';
		}
		if(isset($_GET['name']) && ($_GET['name']=='sap_id')){
			$query.=' and SapId LIKE "%'.$_GET['value'].'%"';
		}
		if(isset($_GET['name']) &&($_GET['name']=='host_name')){
			$query.=' and hostname LIKE "%'.$_GET['value'].'%"';
		}
		if(isset($_GET['name']) && ($_GET['name']=='loop_back')){
			$query.=' and loopback LIKE "%'.$_GET['value'].'%"';
		}
		if(isset($_GET['name']) &&($_GET['name']=='mac_addr')){
			$query.=' and macaddress LIKE "%'.$_GET['value'].'%"';
		}
		
		
		
		  $sql = "select * from  router_details  WHERE  ".$query;
        $stmt = $conn->prepare( $sql );
        $stmt->execute();
        $num = $stmt->rowCount();
  
if($num > 0){
	while($data_11 = $stmt->fetch(PDO::FETCH_ASSOC)){
		$id=$data_11['id'];
		$sap_id=$data_11['SapId'];
		$loopback=$data_11['loopback'];
		$mac_address=$data_11['macaddress'];
		$host_name=$data_11['hostname'];
	echo $saved_comment = '<tr height="20"  id="audit_record_'.$data_11['id'].'">
                <td scope="row" align="left" valign="top" type="name" field="name" class=" "><b>
				'.$sap_id.'</b></td>
                <td align="left" valign="top" type="phone" field="phone_office" class="hidden-xs  phone">
                '.$host_name.'</td>
                <td align="left" valign="top" type="phone" field="phone_office" class="hidden-xs  phone">
                '.$loopback.'</td>
				<td align="left" valign="top" type="relate" field="assigned_user_name" class="hidden-xs ">
                '.$mac_address.'
				 </td>
              <td align="left" class="">
			<button class="delete" data-id="' . $id . '" style="background:#378cbe;color:#f5f5f5;height:40px;"><b>Delete</b></button>
			<button class="edit" data-id="' . $id . '" style="background:#378cbe;color:#f5f5f5;height:40px;"><b>Edit</b></button>
			</td>						
                </tr>';
	}
  	
	
 
 }
  }



	
if (isset($_REQUEST['type'])) {
     if (isset($_POST['type'])) {
	$id=$_POST['id'];

	$sap_id=$_POST['sap_id'];
	$host_name=$_POST['host_name'][0];
	$loopback=$_POST['loop_back'][0];
	$mac_address=$_POST['mac_address'][0];
	$created_date=date('Y-m-d');
	$error='';
	if(!$databaseService->checkunique('loopback',$loopback)){
	$error.='Loop back already exist';
}
if($id==''){
if(!$databaseService->checkunique('hostname',$host_name)){
	$error.='<br/>host Name already exist';
	
}
if(	$error!=''){
	echo json_encode(array('sucess'=>false,'msg'=>$error));
	
	die();
	
}	}
   if($id==''){
	 $sql = "INSERT INTO `router_details` (`id`, `SapId`, `hostname`,`loopback` ,`macaddress`, `date_created`, `deleted`) VALUES (?,?,?,?,?,?,?)";
     $stmt= $conn->prepare($sql);
     $stmt->execute([NULL,$sap_id, $host_name, $loopback,$mac_address,$created_date,0]);
    }else{
	  $sql = "UPDATE `router_details` 
	         SET `SapId`='{$sap_id}',`hostname`='{$host_name}',`loopback`='{$loopback}',`macaddress`='{$mac_address}' where id='{$id}'";
			  $stmt= $conn->prepare($sql);
			  $stmt->execute();
	}
   
  	  if($id==''){ 
	  $id = $conn->lastInsertId();
     }
	$saved_comment = '<tr height="20"  id="audit_record_'.$id.'">
                <td scope="row" align="left" valign="top" type="name" field="name" class=" "><b>
				'.$sap_id.'</b></td>
                <td align="left" valign="top" type="phone" field="phone_office" class="hidden-xs  phone">
                '.$host_name.'</td>
                <td align="left" valign="top" type="phone" field="phone_office" class="hidden-xs  phone">
                '.$loopback.'</td>
				<td align="left" valign="top" type="relate" field="assigned_user_name" class="hidden-xs ">
                '.$mac_address.'
				 </td>
              <td align="left" class="">
			<button class="delete" data-id="' . $id . '" style="background:#378cbe;color:#f5f5f5;height:40px;"><b>Delete</b></button>
			<button class="edit" data-id="' . $id . '" style="background:#378cbe;color:#f5f5f5;height:40px;"><b>Edit</b></button>
			</td>						
                </tr>';
		  echo $saved_comment;
  	}
  }
  // delete comment fromd database
  if (isset($_GET['delete'])) {
	  $id = $_GET['id'];
		$sql = "DELETE FROM router_details WHERE id=" . $id;
        $stmt = $conn->prepare( $sql );
      if($stmt->execute()){
		echo json_encode(array('success'=>true,'deleted'=>1),TRUE);
		exit();
  }else{
	echo json_encode(array('success'=>true,'deleted'=>0),TRUE);
		exit();  
  }
  }
  
  if (isset($_GET['edit'])) {
		$id = $_GET['id'];
		$sql = "select * from  router_details  WHERE id=".$id;
        $stmt = $conn->prepare( $sql );
        $stmt->execute();
        $num = $stmt->rowCount();
  
if($num > 0){
	$data_11 = $stmt->fetch(PDO::FETCH_ASSOC);
echo '<div style="height:300px;" id="create_audit_form"><span><b>Edit Router Detail </b></span><div class="tab-content_2"></div>
  <div class="clear"></div><div class="col-xs-12 col-sm-6 edit-view-row-item">
  <div class="col-xs-12 col-sm-4 label" data-label="LBL_sap_id">SAP ID:</div>
  <div class="col-xs-12 col-sm-8 edit-view-field " type="varchar" field="sap_id">
  <input type="hidden" name="audit_id" id="audit_id" value="'.$data_11['id'].'" >
  <input type="hidden" name="save_type" id="save_type" value="edit" >
  <input type="text" name="sap_id[]" value="'.$data_11['SapId'].'" class="sap_id" id="sap_id" size="30" maxlength="20" value="" title="">
  </div></div>
  <div class="col-xs-12 col-sm-6 edit-view-row-item"><div class="col-xs-12 col-sm-4 label" data-label="LBL_host_name">Host Name:</div>
  <div class="col-xs-12 col-sm-8 edit-view-field " type="varchar" field="host_name">
  <input type="text" name="host_name[]" value="'.$data_11['hostname'].'"  class="host_name" size="30" maxlength="200" value="" title="Host Name"></div></div><div class="clear">
  </div><div class="col-xs-12 col-sm-6 edit-view-row-item"><div class="col-xs-12 col-sm-4 label" data-label="LBL_host_name">Loop Back:</div>
  <div class="col-xs-12 col-sm-8 edit-view-field " type="varchar" field="loop_back">
  <input type="text" name="loop_back[]" value="'.$data_11['loopback'].'"  class="host_name" size="30" maxlength="200" value="" title=""></div></div>
  <div class="col-xs-12 col-sm-6 edit-view-row-item"><div class="col-xs-12 col-sm-4 label" data-label="LBL_mac_address">MAC Address:</div>
  <div class="col-xs-12 col-sm-8 edit-view-field "  type="varchar" field="mac_address">
  <input type="text" name="mac_address[]" class="mac_address" value="'.$data_11['macaddress'].'" size="30" maxlength="20" value="" title="MAC Address">
  </div></div><div class="clear"></div>
  ';
    }
  }
  

?>
