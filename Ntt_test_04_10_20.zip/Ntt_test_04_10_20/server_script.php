<?php
///Excersise 2 Question 1. a. Telnet to the server.


$cfgPort    = "8080";                //port, 22 if SSH
$cfgTimeOut = "5";
$cfgServer ="localhost";

$f=fsockopen("$cfgServer",$cfgPort,$cfgTimeOut);
if (!$f)
{
echo "<pre>";
echo "not connected\\r\
";

}
else
{
echo "<pre>";
echo "connected\\r\
";

?>

