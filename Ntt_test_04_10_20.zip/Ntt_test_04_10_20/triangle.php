<?php
// Create a blank image
$image = imagecreatetruecolor(400, 300);

// Allocate a color for the polygon
$col_poly = imagecolorallocate($image, 255, 255, 255);

// Draw the polygon
imagepolygon($image, array(
        230,20,          
	    220, 50,
		240,50
       ),
    3,
    $col_poly);
imagepolygon($image, array(
        310,120,          
	    300, 150,
		320,150
       ),
    3,
    $col_poly);
imagepolygon($image, array(
        160,120,          
	    150, 150,
		170,150
       ),
    3,
    $col_poly);

$img_height=60;
$img_width=50;
imageline ($image,230,50,
                 310,120,$col_poly);

imageline ($image,230,50,
                 160,120,$col_poly);

imageline ($image,160,120,
                  310,120,$col_poly);
// Output the picture to the browser
header('Content-type: image/png');
imagepng($image);
imagedestroy($image);
?>

