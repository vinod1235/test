-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2020 at 07:54 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `satta`
--

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` text CHARACTER SET utf16 COLLATE utf16_unicode_ci,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `whatsapp` varchar(255) DEFAULT NULL,
  `address` text,
  `value` varchar(255) DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`id`, `name`, `title`, `phone`, `email`, `price`, `whatsapp`, `address`, `value`, `status`) VALUES
(1, 'Mahesh kumar', 'अपनी सट्टा मटका गेम का रिज़ल्ट हमारी वेबसाइट पर डलवाने के लिए कॉल करें.\r\n', '7503212148', 'amitkumarviet@gmail.com', 800, '7503212148', 'test test', '7503212148', 1);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `deleted`) VALUES
(1, 'amit', '0cb1eb413b8f7cee17701a37a1d74dc3', 0);

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m170102_161634_init', 1589122697);

-- --------------------------------------------------------

--
-- Table structure for table `router_details`
--

CREATE TABLE `router_details` (
  `id` int(11) NOT NULL,
  `SapId` varchar(255) DEFAULT NULL,
  `hostname` varchar(255) DEFAULT NULL,
  `ip_addr` varchar(255) DEFAULT NULL,
  `loopback` varchar(255) DEFAULT NULL,
  `macaddress` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `router_details`
--

INSERT INTO `router_details` (`id`, `SapId`, `hostname`, `ip_addr`, `loopback`, `macaddress`, `date_created`, `deleted`) VALUES
(1, 'wqeqweqweqwreterterter', 'www.google.com', NULL, '192.168.168.12', 'wqeqweqweqwretertert', '2020-06-07 00:00:00', 0),
(4, 'fdsfsdfdsfdsfdsfdsfds', 'dfsfsdfsdfdsfdsfd', NULL, '192.168.13.13', 'dfsfsdfsdfdsfdsfd', '2020-06-07 00:00:00', 0),
(5, 'b6mDQNvt8hoIqUziAMnT', 'www.pO14GrbDSqWK87YtZdky.com', '122.84.19.100', '235.24.130.25', '20:62:ad:18:10:a8', '2020-06-07 07:23:58', 0),
(6, '9PjugtFJ6lsSxfpGInqz', 'www.08BnMseYQbdAkNDWvtXU.com', '170.181.135.125', '252.6.55.82', '4f:d3:35:4d:43:13', '2020-06-07 07:23:58', 0),
(7, 'CjRfqPsJ4NEghMHLkTIG', 'www.jtLHTWs8x3iBDkJEYncp.com', '136.18.131.120', '198.118.106.109', 'ff:24:65:4e:36:10', '2020-06-07 07:23:58', 0),
(8, 'brNZfsl2MuQ0nw9yKSao', 'www.eBJmCLoA7thMHKQnb3GU.com', '156.210.222.106', '165.218.229.162', 'f9:b7:09:5a:9b:4 ', '2020-06-07 07:23:58', 0),
(9, 'CbIAgD3oYRd1zXeNSlL6', 'www.ILqWlcfv4zSwCPn185Gd.com', '183.67.236.213', '223.31.254.151', '87:78:49:e1:38:e1', '2020-06-07 07:23:58', 0),
(10, 'sdfsdfdsfsdfsdfsdfdsfsdfsdfsdfsdfdsfds', 'www.google.com111', NULL, '192.168.168.11', 'www.google.com111', '2020-06-07 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_live_satta`
--

CREATE TABLE `tbl_live_satta` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `time_opened` datetime NOT NULL,
  `number_gussed` int(11) NOT NULL,
  `number_opened` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `status` tinyint(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_live_satta`
--

INSERT INTO `tbl_live_satta` (`id`, `name`, `time_opened`, `number_gussed`, `number_opened`, `date_created`, `status`) VALUES
(1, 'DESAWAR\r\n', '2020-04-11 05:00:00', 60, 65, '2020-04-09 00:00:00', 1),
(2, 'FARIDABAD', '2020-04-11 05:00:00', 60, 65, '2020-04-09 00:00:00', 1),
(3, 'GAZIYABAAD', '2020-04-11 05:00:00', 60, 65, '2020-04-09 00:00:00', 1),
(4, 'GALI', '2020-04-11 05:00:00', 60, 65, '2020-04-09 00:00:00', 1),
(5, 'HINDUSTAN', '2020-04-11 05:00:00', 60, 65, '2020-04-09 00:00:00', 1),
(6, 'HARYANA KING', '2020-04-11 05:00:00', 60, 65, '2020-04-09 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_satta`
--

CREATE TABLE `tbl_satta` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `status` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_satta`
--

INSERT INTO `tbl_satta` (`id`, `name`, `title`, `date_created`, `status`) VALUES
(1, 'Satta King Gali Chart 2019\r\n', NULL, '2019-12-15', 1),
(2, 'GALI RECORD CHART 2019\r\n', NULL, '2019-12-15', 1),
(3, 'DESHAWAR RECORD CHART 2019\r\n', NULL, '2019-12-15', 1),
(4, 'GHAZIABAD RECORD CHART 2019\r\n', NULL, '2019-12-15', 1),
(5, 'FARIDABAD RECORD CHART 2019\r\n', NULL, '2019-12-15', 1),
(6, 'HERO-(Z) RECORD CHART 2019\r\n', NULL, '2019-12-15', 1),
(7, 'SATTA GALI DISAWAR RECORDS CHART\r\n', NULL, '2019-12-15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_satt_chart`
--

CREATE TABLE `tbl_satt_chart` (
  `id` int(11) NOT NULL,
  `year` varchar(255) DEFAULT NULL,
  `month_date` int(11) DEFAULT NULL,
  `satta_id` int(11) DEFAULT NULL,
  `jan` int(11) DEFAULT NULL,
  `feb` int(11) DEFAULT NULL,
  `march` int(11) DEFAULT NULL,
  `april` int(11) DEFAULT NULL,
  `may` int(11) DEFAULT NULL,
  `june` int(11) DEFAULT NULL,
  `july` int(11) DEFAULT NULL,
  `aug` int(11) DEFAULT NULL,
  `sept` int(11) DEFAULT NULL,
  `october` int(11) DEFAULT NULL,
  `nov` int(11) DEFAULT NULL,
  `december` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_satt_chart`
--

INSERT INTO `tbl_satt_chart` (`id`, `year`, `month_date`, `satta_id`, `jan`, `feb`, `march`, `april`, `may`, `june`, `july`, `aug`, `sept`, `october`, `nov`, `december`) VALUES
(1, '2019', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
(2, '2019', 1, 1, 8, 97, 25, 18, 79, 14, 76, 22, 96, 55, 98, 40),
(3, '2019', 1, 2, 94, 65, 37, 63, 40, 30, 56, 93, 27, 12, 71, 28),
(4, '2019', 1, 3, 29, 21, 45, 89, 11, 8, 73, 89, 51, 40, 27, 58),
(5, '2019', 1, 4, 86, 85, 45, 78, 77, 99, 93, 61, 0, 92, 56, 22),
(6, '2019', 1, 5, 31, 89, 49, 92, 80, 43, 59, 11, 6, 69, 94, 16),
(7, '2019', 1, 6, 5, 51, 46, 6, 48, 59, 92, 13, 17, 55, 80, 24),
(8, '2019', 1, 7, 84, 7, 16, 41, 16, 20, 10, 88, 20, 76, 44, 74),
(9, '2019', 1, 8, 61, 96, 9, 34, 85, 15, 57, 63, 28, 75, 2, 17),
(10, '2019', 1, 9, 12, 58, 2, 76, 99, 12, 88, 84, 57, 35, 52, 76),
(11, '2019', 1, 10, 75, 24, 19, 76, 60, 51, 28, 0, 81, 78, 16, 64),
(12, '2019', 1, 11, 59, 43, 2, 63, 71, 28, 48, 93, 0, 18, 86, 17),
(13, '2019', 1, 12, 63, 79, 13, 62, 9, 37, 2, 46, 22, 56, 4, 70),
(14, '2019', 1, 13, 58, 69, 49, 27, 94, 28, 23, 4, 95, 3, 14, 93),
(15, '2019', 1, 14, 0, 61, 7, 42, 74, 13, 99, 27, 86, 44, 57, 79),
(16, '2019', 1, 15, 13, 22, 8, 27, 61, 79, 99, 70, 26, 92, 4, 0),
(17, '2019', 1, 16, 77, 22, 2, 3, 3, 54, 98, 96, 38, 73, 51, 0),
(18, '2019', 1, 17, 1, 66, 37, 14, 68, 75, 59, 0, 60, 57, 82, 0),
(19, '2019', 1, 18, 3, 85, 65, 80, 51, 77, 76, 54, 27, 11, 42, 0),
(20, '2019', 1, 19, 69, 28, 46, 43, 9, 88, 44, 89, 39, 83, 32, 0),
(21, '2019', 1, 20, 33, 28, 39, 84, 75, 51, 79, 58, 14, 73, 8, 0),
(22, '2019', 1, 21, 32, 58, 38, 24, 81, 65, 23, 98, 86, 60, 87, 0),
(23, '2019', 1, 22, 62, 72, 46, 74, 98, 33, 50, 18, 94, 18, 30, 0),
(24, '2019', 1, 23, 0, 7, 83, 78, 27, 40, 56, 92, 46, 6, 37, 0),
(25, '2019', 1, 24, 73, 22, 70, 3, 28, 25, 97, 90, 81, 60, 66, 0),
(26, '2019', 1, 25, 60, 55, 38, 92, 15, 94, 52, 40, 18, 29, 90, 0),
(27, '2019', 1, 26, 90, 37, 40, 29, 76, 63, 6, 19, 42, 0, 72, 0),
(28, '2019', 1, 27, 23, 39, 70, 25, 44, 5, 37, 95, 51, 0, 61, 0),
(29, '2019', 1, 28, 3, 0, 43, 83, 57, 25, 70, 7, 44, 0, 96, 0),
(30, '2019', 1, 29, 77, 0, 60, 11, 99, 89, 39, 2, 26, 0, 81, 0),
(31, '2019', 1, 30, 59, 0, 44, 0, 96, 0, 67, 24, 0, 0, 0, 0),
(32, '2019', 1, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `p_id` int(11) DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_balance` decimal(26,2) DEFAULT NULL,
  `commision` decimal(26,2) DEFAULT '0.00',
  `userUniqueID` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pan_card_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `aadhaar_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `district` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `aadhaar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pan_card` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `block` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `user_type` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `p_id`, `username`, `full_name`, `account_balance`, `commision`, `userUniqueID`, `photo`, `pan_card_no`, `aadhaar_number`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `address`, `phone`, `state`, `district`, `aadhaar`, `pan_card`, `block`, `status`, `user_type`, `created_at`, `updated_at`) VALUES
(5, NULL, 'DOSADMIN', 'SAMEER TYAGI', '700.00', '416.00', '', '437220200116050602imgimage002 (1).jpg', 'AZHPT8689G', '941969466882', 'iNFA1ZAnHmaBdAG0vJnevvWqM7vcqQdx', '$2y$13$2iRzZqRk5KaBjYyHmk00aOxGsCVzdWraEpvu/SUjya/HimFzALxx.', NULL, 'amitkumarviet12333@gmail.com', 'MUZAFFARNAGAR', '9045140921', '33', '222', '103820200116050602imgNAMED.jpg', '685420200116050602imgWhatsApp Image 2019-11-13 at 13.29.23.jpeg', 'MUZAFFARNAGAR', 10, 0, 1553761787, 1579626638),
(6, NULL, 'DOSSM100010', 'MUSTAFA TYAGI', '1000.00', '8.00', '', '982920190428055610imgPIC.jpg', 'EIJPS38F', '555555555555', 'Y7PLM4Tz54b6u24YxcxNejw5OHamT-KV', '$2y$13$V4xL0GD4QZC3033QIrcxN.dk1TE9JQnesUSGybkbYbDh5WV6MVx76', NULL, 'COSAMEERTYAGI@GMAIL.COM', 'MUZAFFARNAGAR', '7417562109', '33', '222', '989320190428055610imgPIC.jpg', '650220190428055610imgPIC.jpg', 'MUZAFFARNAGAR', 1, 0, 1554024011, 1559371885),
(7, NULL, 'DOSDM100011', 'SHIV KUMAR KHURD', '1000.00', '16.00', '', '309420190430031913imga191b477-fbc2-4170-8094-fa0e310609bf.jpg', 'BQQPK7038B', '922222117739', 'HzpUVnHwaK-NnVHT2ESETrH9CHb0yt3y', '$2y$13$VJZDC.7dJ.F/eu4roCWns.xl4SL71Ma3xcjh89aPyDcLZsuBjibXC', 'MzY3ZGFiYzNkMjNlMzczZDUyYmZkMDZmNTVjZWJjYzEyNDUwZmZhMQ==', 'ashivn20818@gmail.com', 'SHIV NAGAR GALI NO-13 GANDHI COLONY MUZAFFARNAGAR', '6398464083', '33', '222', '623520190430031913img5544b4de-e211-423c-8c8f-1b2b9ca83316.jpg', '47520190430031913img1ad1b896-a41a-4e89-a005-126c0758c6a0.jpg', 'MUZAFFARNAGAR', 1, 0, 1554609245, 1559371885),
(8, NULL, 'DOSBC100012', 'PREM TYAGI', '1010.00', '35.00', '', 'download73bdb789008641ce1e3bc130a9463554.jpeg', 'EIJPS9438F', '587500720931', '5pT-N3dLkTkgHqeWDeYA8LczrsltWjP5', '$2y$13$lDJiBiq8XIWE0EQdk3/QF.HiYPQkp6oKn89IcMwbMWm.Y5QBcNHmW', '5uz_JHHJ3pFEHLL17d7UaguGroXwGLPX_1556534002', 'PREMTYAGI@GMAIL.COM', 'MUZAFFARNAGAR', '6397568956', '33', '222', 'download73bdb789008641ce1e3bc130a9463554.jpeg', 'download73bdb789008641ce1e3bc130a9463554.jpeg', 'MUZAFFARNAGAR', 1, 0, 1554617876, 1559133568),
(9, NULL, 'DOSVLE100009', 'IMRAN', '827.00', '0.00', '', '768320190512080503imgIIIII.jpg', 'KASAS9622D', '889975335825', 'yn79_z97QBSe9lixd9K7luYv3Q9_s0AE', '$2y$13$lFaJeqdv25BRDeaRpiJF1uEiMMbo.TlFAZvbgXrRAWk5EFNWHhZAK', NULL, 'SAMEERSAGEER0@GMAIL.COM', 'HOUSE NO.1180\r\nBEECH WALI MASJID\r\n(TYAGI CHOWK)SARWAT M.Z.N.', '80572213442', '33', '222', '763720190512080503imgScan2019-05-12_122643_003.jpg', '922720190512080503imgScan2019-05-12_122643_004.jpg', 'MUZAFFARNAGAR', 1, 0, 1554621404, 1559133569),
(10, NULL, 'DOSVLE100010', 'MOHD SAMEER', '468.00', '0.00', '', 'a9c536cf-fa48-45ea-baa9-4611838c0f542f8c1ca0ad45aa9c30d647b1531abffe.jpg', 'KASAS9622J', '658685907497', 'ogIWID3BntVnJUYN9r1X_bC_FV-tKU49', '$2y$13$LrBVDlvjmxc/ojXbb2eO4eZGTNzjwdsstGzrzKy/f4b1AdZD2kBya', NULL, 'SAMAR@GMAIL.COM', 'HOUSE NO.1180\r\nBEECH WALI MASJID\r\n(TYAGI CHOWK)SARWAT M.Z.N.', '7500075288', '33', '219', '7542ebf2-a814-44e7-9d1a-c6d365f52b452f8c1ca0ad45aa9c30d647b1531abffe.jpg', '7542ebf2-a814-44e7-9d1a-c6d365f52b452f8c1ca0ad45aa9c30d647b1531abffe.jpg', 'khatoli', 10, 0, 1554621602, 1555843156),
(11, NULL, 'DOSSM100011', 'Amit Kumar Sahu', '500.00', '0.00', '', 'downloadb0b5310a68b2220ee64b0a92abc351fa.jpeg', 'EIJPS9438F', '587500720931', 'j--RGoVtSNyFY0W5goZe8NBWs3TrSBIt', '$2y$13$KdGbqNgJ2J5OYSjlI.ohFO/EbcOKdwhVcHiMaME6bgdy2m7sIvzw6', NULL, 'amitkumarvie1111t@gmail.com', 'test address', '7503212148', '17', '606', '653820190409060640imgdownload.jpeg', '903920190409060640imgdownload.jpeg', 'Hassan', 0, 0, 1554746768, 1554746769),
(12, NULL, 'DOSSM100012', 'SUAIB', '500.00', '0.00', '', '541e2362-64e6-4865-b64f-971eef4dd9524f7ba97b85aabe0f8b901dd1ac0fcabe.jpg', 'ABGOG5852J', '123456789101', 'YQp8vsF2l0FSN_Npk8AD0vgxa8vguSkx', '$2y$13$va8MugVV4xxwBqEaZe9IX.PmRwbTK4refQfpwhA3Hb6Imt5Oz6/UG', NULL, 'SUAIN123@GMAIL.COM', 'MUZAFFARNAGAR', '9045802011', '34', '95', '541e2362-64e6-4865-b64f-971eef4dd9524f7ba97b85aabe0f8b901dd1ac0fcabe.jpg', '541e2362-64e6-4865-b64f-971eef4dd9524f7ba97b85aabe0f8b901dd1ac0fcabe.jpg', 'DEHRADUN', 0, 0, 1554782114, 1554782115),
(14, NULL, 'DOSVLE100013', 'sameer hasan', NULL, '0.00', '', 'PHOTOa74c48fa4c6e6a9bfdb0ded8f6e94253.jpg', 'AQSPH2963H', '335429003035', 'G_JKhxMX2_VNZGcBCidQbHYWrHkrQbwZ', '$2y$13$EQtC3g3X1zHgAOgDBJYjYuIYRxM8hXrn8wnfwcWcIcCwxVBB./Jl2', NULL, 'szaidi605@gmail.com', 'house no 200, vahalana,muzaffarnagar,uttarpradesh,251003', '9012854090', '33', '222', 'AADHAR CARD 100a74c48fa4c6e6a9bfdb0ded8f6e94253.jpg', 'PANa74c48fa4c6e6a9bfdb0ded8f6e94253.jpg', 'MUZAFFARNAGAR', 10, 0, 1555996524, 1555996524),
(15, NULL, 'DOSVLE100015', 'SUAIB', NULL, '0.00', '', '541e2362-64e6-4865-b64f-971eef4dd952d2038b412ecfd4750ef5e82fcad30efa.jpg', 'ACVFD8584A', '000000000000', 'yVG6JaqoktnTAKVv7Pfspx5Q-d2B8_xi', '$2y$13$QBwwEHk5l2QHaB9gfOA3vOPtXhXgmt/4nRL6UM14D5Cx6z1dp5x6O', NULL, 'SAMEERTYAGI400@GMAIL.COM', 'MUZAFFARNAGAR', '9045802011', '33', '222', '541e2362-64e6-4865-b64f-971eef4dd952d2038b412ecfd4750ef5e82fcad30efa.jpg', '541e2362-64e6-4865-b64f-971eef4dd952d2038b412ecfd4750ef5e82fcad30efa.jpg', 'MUZAFFARNAGAR', 10, 0, 1555996736, 1555996736),
(16, NULL, 'DOSVLE100016', 'DINESH KUMAR', NULL, '0.00', '', 'D918bf4f92b48f389879b5a55472fb762.jpg', 'dwkpk2224p', '239607958020', 'UHWA6h8gKS6s4sactRIVzYiUBoHsM2CZ', '$2y$13$TN8FnmO72tBQvp39mEkT/eEywsZ0DjAUHaThYf0Q0yCWOZ7yK8mr6', NULL, 'dineshemail1992@gmail.com', 'village dabkora post behat distt saharanpur', '9627255902', '33', '227', 'dinesh adhar918bf4f92b48f389879b5a55472fb762.jpg', 'pan card918bf4f92b48f389879b5a55472fb762.jpg', 'sadholi kadim', 10, 0, 1556172840, 1556172840),
(17, NULL, 'DOSVLE100017', 'vishal saini', '1000.00', '0.00', '', '169220190503104516imgBeautyPlus_20170413102113_save.jpg', 'JYCPS1443C', '', 'kqxR1rNHkRTYtlHgNN642dgtIparSK2A', '$2y$13$g53wEZX/9.a1Y85VgETXou/WXi/wHIvizcUbh3HwUMvQa0foKqMmS', NULL, 'vishalsainid2018@gmail.com', 'janshat road almaspur muzaffarnager', '7983551841', '33', '222', 'aadhar front85d0f63a4bdfbc9711a17ade895b1407.jpg', 'pancard85d0f63a4bdfbc9711a17ade895b1407.jpg', 'MUZAFFARNAGAR', 10, 0, 1556186803, 1556525732),
(18, NULL, 'DOSVLE100018', 'Suraj Kumar', '756.00', '1000.00', '', 'Webp.net-resizeimage4c8f78c3f9e491117cd8c94f1991acf1.jpg', 'CADPK7336N', '236992786396', '5ha8hZ-I69E5wS96i5CV_h5BbpGzvwwJ', '$2y$13$FeaRSKzf/Cy.nhw2fZ0yfeGISoS9bkcKvUKtGrld4ZizqsGUsKXWS', NULL, 'dheerdhyan@gmail.com', '890 vill and post Barwala ', '8954799387', '33', '222', 'Webp.net-resizeimage (1)4c8f78c3f9e491117cd8c94f1991acf1.jpg', 'Webp.net-resizeimage (2)4c8f78c3f9e491117cd8c94f1991acf1.jpg', 'Baghra', 10, 0, 1556269164, 1579626638),
(19, NULL, 'DOSVLE100019', 'RAHUL KUMAR', NULL, '0.00', '', '30 KB copy455e31ac2c5ce3ff39cbbb4e57c53608.jpg', 'DVSPK7082Q', '518033332940', 'WaV4G4IRQpavwZOLFy3eAigOvsilAplT', '$2y$13$y6kFFqcbzQvFyucmpZYmvuRM5llR8oZCQl/6zOVAV4UJ2Bjt5f5MW', NULL, 'humtum8126@gmail.com', 'VPO SIKHERA', '9012171714', '33', '222', 'AADHAR CARD455e31ac2c5ce3ff39cbbb4e57c53608.jpg', '089455e31ac2c5ce3ff39cbbb4e57c53608.jpg', 'JANSATH', 10, 0, 1556270745, 1556270745),
(20, NULL, 'DOSVLE100020', 'MEENU', '100.00', '0.00', '', 'tttttt3a8d2ae0b5e44724d7d7b40a8f6ae280.jpg', 'DLJPM1923H', '885984437370', 'eTBu6WHm-OBzcfBsKhA1Uq1xFDZF-gnG', '$2y$13$2sX3IMzjaxZLHWRJ.nnf/esIBuUR2N7ncnFBwqzMz9JZkfwJw1Dua', NULL, 'badalbaliyan@gmail.com', 'VILL POST SHORON DISTT MUZAFFARNAGAR STATE UP 251318', '9997013378', '33', '222', '073a8d2ae0b5e44724d7d7b40a8f6ae280.jpg', '093a8d2ae0b5e44724d7d7b40a8f6ae280.jpg', 'SHAHPUR', 10, 0, 1556271215, 1579429532),
(21, NULL, 'DOSVLE100021', 'VINAI KUMAR', NULL, '0.00', '', '005(1)606e7e147b9542a7f35a0206b3e1b410.jpg', 'BAWPK9936Q', '667678381296', 'IbedLTxAJCyW7iRks1paXvKlqXInJe5t', '$2y$13$WQkVzLaW6IvR.0ok5mrGFuw0/YotCIuwzZ3z.vmrmXJStVfw3O/oy', NULL, 'vinaipundirmzn@gmail.com', 'village and post kacholi \r\n  block charthawal\r\npin  251202', '09557036795', '33', '222', 'lic-aadhar606e7e147b9542a7f35a0206b3e1b410.jpg', 'pen card606e7e147b9542a7f35a0206b3e1b410.jpg', 'charthawal', 10, 0, 1556274239, 1556274239),
(22, NULL, 'DOSVLE100022', 'ARVIND KUMAR', NULL, '0.00', '', 'PHOTOd4e48f13e217a779649d668847ab3df5.jpg', 'BSBPK8083R', '355933697755', 'EIMduYyCmI1TA9iZ6T19aJxxsXvnZRwa', '$2y$13$nMC1/8AiQG8Aw8pelzDo0uR3JR1lu1vmUZjr1j0.4y64itAVJ5oqS', NULL, 'ARVINDKUMAR546@GMAIL.COM', 'VPO SAMBHALHERA TEHSIL JANSATH DISTT MUZAFFARNAGAR 251314', '9359232425', '33', '222', '0001ad4e48f13e217a779649d668847ab3df5.jpg', 'arvind pan1d4e48f13e217a779649d668847ab3df5.jpg', 'JANSATH', 10, 0, 1556281412, 1556281412),
(23, NULL, 'DOSVLE100023', 'DEEPAK KUMAR', NULL, '0.00', '', 'deepak aryafb90cf2c84025e6a653de084808e887b.jpg', 'GLRPK2211P', '450159253547', 'opI1GxJKVeCm9rAVJY3pNJDz7bzHJWZK', '$2y$13$qCxpkMntBOZaoibTAaE/seNR6LFaUMumQw5d6Z0eM5pl4ztS8OG0K', NULL, 'aaryadeepak62@gmail.com', 'MOHALLA HALWAIYAN POST CHARTHAWAL DISTT MUZAFFARNAGAR', '8937816285', '33', '222', 'aadhar card deepakfb90cf2c84025e6a653de084808e887b.jpg', 'pancardfb90cf2c84025e6a653de084808e887b.jpg', 'CHARTHAWAL', 10, 0, 1556358859, 1556358860),
(24, NULL, 'DOSDM100024', 'Amit Kumar Sahu', NULL, '0.00', '', 'images6e5cfd013b39037a6db003640bcbf40b.jpeg', 'EIJPS9438F', '587500720931', '5xdUvgFv-qj0izeW7ptN9c0rvn5fsXkg', '$2y$13$JkWcrtmAfsMxA0bo69WE2.4PM45TNP7d6jbgrTcelFx./sKt6hAj.', NULL, 'amitkumarv6666iet@gmail.com', 'Testtfdgdfgdgdf', '7503212148', '17', '606', 'images6e5cfd013b39037a6db003640bcbf40b.jpeg', 'images6e5cfd013b39037a6db003640bcbf40b.jpeg', 'Mandawali', 0, 3, 1556437263, 1556437263),
(25, NULL, 'DOSDM100025', 'Amit Kumar Sahu', NULL, '0.00', '', 'imagesab29f74304b6d3efd9768ca130467d9f.jpeg', 'EIJPS9438F', '587500720931', '-h9PGwpvI5U2RIrooVz3U8pDBP_dUL1f', '$2y$13$hPKD8cKHybddViSm5.ZHjef8hx5cyt8WvX/Gw8RLMCx7smQxFvWm2', 'OWVlZDJhNzg2Y2ZkYTFiMmFmZGRmYTE0YTZiYjY4NWQyZDBmOTk1Yg==', 'amitkumarviet@gmail.com', 'Testtfdgdfgdgdf', '7503212148', '33', '182', 'banner_images2ab29f74304b6d3efd9768ca130467d9f.jpeg', 'banner_images2ab29f74304b6d3efd9768ca130467d9f.jpeg', 'Mandawali', 0, 3, 1556438787, 1556438787),
(26, NULL, 'DOSBC100026', 'ARVIND KUMAR', NULL, '0.00', '', 'ARVIND KUMAR PHOTO9ea26e54fa9293c503b649936f93cbbc.jpg', 'BSBPK8083R', '355933697755', 'A3XRMe1xXc8AqQhU8DIv2fqvmjXABq28', '$2y$13$hdRbcZ2fEImqXI8BTh/FUOxjq5CP3XgnQx.YCVfY4S42zRKTh4HaS', NULL, 'cscsambhalhera@gmail.com', '796,SAMBHALHERA, MUZAFFARNAGAR ', '9997085023', '33', '222', 'ARVIND KUMAR AADHAR9ea26e54fa9293c503b649936f93cbbc.jpg', 'ARVIND KUMAR PAN9ea26e54fa9293c503b649936f93cbbc.jpg', 'JANSATH', 10, 4, 1556439754, 1556439754),
(27, NULL, 'DOSBC100027', 'SURAJ KUMAR', NULL, '35.00', '', 'suraj_3_2fa71a8773c7afcbc683aa94f2fee0928.jpg', 'CADPK7336N', '236992786396', 'E2SL0upVtxtOyUt41tD-VL1He-WCwHKf', '$2y$13$oAcnDhZS7Dx7zXvazagMP.wm2CLLwZO2ObaHXswkoxqGFgcyL6XPe', NULL, 'Dheerdhyan84@gmail.com', 'vill and post Barwala,Muzaffarnagar', '7017745160', '33', '222', 'Aadhar Card D.D - Copyfa71a8773c7afcbc683aa94f2fee0928.jpg', 'Pan Card DSC03635fa71a8773c7afcbc683aa94f2fee0928.jpg', 'BAGHARA', 10, 4, 1556445899, 1579626638),
(28, NULL, 'DOSDM100028', 'DINESH KUMAR', NULL, '0.00', '', 'D489ee1cd636568f31f6a660f4d2115d4.jpg', 'DWKP2224P', '239607958020', 'jfp7qI1GI3PG2S6YkLmKMJ-5mReaAVkt', '$2y$13$LGRiLedfAsFsa.b1PzksPe5VvJpYnimc75fCCwK0caI.jf7WHtLf.', NULL, 'dineshdhiman_143@rediffmail.com', 'VILLAGE - DABKORA,POST - BEHAT,DISTT - SAHARANPUR', '7351755902', '33', '227', 'dinesh adhar489ee1cd636568f31f6a660f4d2115d4.jpg', 'pan card489ee1cd636568f31f6a660f4d2115d4.jpg', 'SADHOLI KADIM', 10, 3, 1556446929, 1556446929),
(29, NULL, 'DOSVLE100029', 'KARAM VEER SINGH', NULL, '0.00', '', 'PHOTO173094754bce87303fe6340aa6441fbf.jpg', 'DOUPS9635J', '511940055083', '0wBZpGkntKpdHq-GYnimnkhe57dVQw-m', '$2y$13$YKcd02n9qTqtSY3kEajRK.edremplNVPb1O.b/A5zaxdE..903kgm', NULL, 'Karamveersingh28051@gmail.com', 'VPO SIKANDERPUR TEHSIL JANSATH DISTT MUZAFFARNAGAR', '9997774283', '33', '222', 'AADHAR173094754bce87303fe6340aa6441fbf.jpg', 'PAN173094754bce87303fe6340aa6441fbf.jpg', 'JANSATH', 10, 5, 1556457400, 1556457400),
(30, NULL, 'DOSVLE100030', 'MUHAMMAD SADIQUE', NULL, '0.00', '', 'sadik47b6ec2b079cfc389871e553d9af26f0.jpg', 'HQRPS0267K', '452753537115', 'c_uruErp0Z33cqzAQORpDlbVTkmJ301B', '$2y$13$GZe018OOz9V9t4z0941qyOD0Sr1oAwQiwWzsuYBKs4qwkOklPLJAK', NULL, 'sadikt758@gmail.com', 'village post chokra block charthawal district muzaffarnagar', '7078532390', '33', '222', 'AADHAR47b6ec2b079cfc389871e553d9af26f0.jpg', '1047b6ec2b079cfc389871e553d9af26f0.jpg', 'CHARTHAWAL', 10, 0, 1556508263, 1556508263),
(31, NULL, 'DOSVLE100031', 'AMIT KUMAR', NULL, '0.00', '', '00671b509b63ee825da9a014db4bee3938f.jpg', 'EFVPK7809R', '334428495133', '-fQigVDvzh2SkWGoNcTAsIV8QYZCNnbj', '$2y$13$6AHNdtJd7uv3p2WtqwTVcOwdcQMsACDycxz96MJnCqFV/dmh.giIi', NULL, 'amitpal348@gmail.com', 'AMIT VIHAR COLONY KUKRA KUKRA MUZAFFARNAGAR UP 251001', '8923122228', '33', '222', 'aadhar.jpg csc71b509b63ee825da9a014db4bee3938f.jpg', 'PAN CSC IRCTC71b509b63ee825da9a014db4bee3938f.jpg', 'MUZAFFARNAGAR', 10, 0, 1556518091, 1556518092),
(32, NULL, 'DOSBC100032', 'SUBODH RANA', NULL, '0.00', '', 'bc61ea69-abe1-4dc2-9285-59906701c7f44bf3ea7a7f97b85b427699ba4f3b8e87.jpg', 'CCGPR3842F', '653570157475', 'Ml3n1OWojdvni8TppZBlKOxpoA9LtKP1', '$2y$13$/upHAHBG5JgXdn.diirSEu30dkeUYeO6zNEk0cBorFbNP.5zGk9I.', NULL, 'ranasubodh_143@rediffmail.com', 'VILLAGE SHAHPUR\r\n\r\nPOST BEHAT', '9759500099', '33', '227', 'SUB4bf3ea7a7f97b85b427699ba4f3b8e87.jpg', '81ed38ff-b6a7-42cd-8762-5568195bfc224bf3ea7a7f97b85b427699ba4f3b8e87.jpg', 'SADHOLI KADIM', 10, 4, 1556518319, 1556518319),
(33, NULL, 'DOSVLE100033', 'MUHD YUNUS SALIM', NULL, '0.00', '', '19fb0927-6006-48e3-84e0-ec7acb78fb4c0bacb284e1032d3796e720f49ae7a13d.jpg', 'CAKPS4880E', '203215564433', 'N38owQ80yoyBWuBLot9m-uTNtQyXh-Y9', '$2y$13$/9owLESrMors6OnUm.8UjOKWYxJARjFo5bl/cZY7nhP43yove03Dy', NULL, 'YUNUSSALIM555@GMAIL.COM', '226 CHHAPAR,NEAR JAMA MASZID,CHHAPAR,MUZAFFARNAGAR', '9359524555', '33', '222', 'YUNUS_page-00010bacb284e1032d3796e720f49ae7a13d.jpg', '1a559073-f52f-4a9e-a340-1df63bd320950bacb284e1032d3796e720f49ae7a13d.jpg', 'PURKAZI', 10, 0, 1556518342, 1556518342),
(34, NULL, 'DOSBC100034', 'MUHD YUNUS SALIM', NULL, '0.00', '', '19fb0927-6006-48e3-84e0-ec7acb78fb4c94c1257a7d8fe6d2dbe63076ac92ca50.jpg', 'CAKPS4880E', '203215564435', '1g-GoZstm0NA41jvhjjLrOJmi2h_JHAq', '$2y$13$BZraanaNznBAsiKJ5EgVV.RAifZqRQogaQ9kYfXwk0mcCXRlD834S', NULL, 'MUHDYUNUSSALIM872@GMAIL.COM', '226,CHHAPAR,NEAR JAMA MASZID,CHHAPAR,MUZAFFARNAGAR', '8077196586', '33', '222', 'YUNUS_page-000194c1257a7d8fe6d2dbe63076ac92ca50.jpg', '1a559073-f52f-4a9e-a340-1df63bd3209594c1257a7d8fe6d2dbe63076ac92ca50.jpg', 'PURKAZI', 10, 4, 1556518902, 1556518902),
(35, NULL, 'DOSBC100035', 'PRAVEEN KUMAR', NULL, '0.00', '', 'img20180526_1432348678f4e6cf242aaf0c0d92b5b978440068.jpg', 'BHEPK2728P', '360880446354', 'NFLMGJEiAVKZmTjCA1Dzzrl4BZOEcLCx', '$2y$13$G.gxkAwo9mxrm2eIlfPomugA7RFrVm/OMlyZf7Pc0FBourHCtRIB6', NULL, 'praveendhimanavanti@gmail.com', 'VILLAGE - NAURANGPUR\r\nPOST - JAHANPUR\r\nTEHSIL - BEHAT', '9758599254', '33', '227', 'pra78f4e6cf242aaf0c0d92b5b978440068.jpg', '5cee4f99-2768-4d19-944c-e49337daac5678f4e6cf242aaf0c0d92b5b978440068.jpg', 'MUZAFFRABAD', 10, 4, 1556673949, 1556673949),
(36, NULL, 'DOSBC100036', 'DHARMENDRA', NULL, '0.00', '', '2ce6ab12-50cc-440e-9ce6-7daacd998bc8cb9571b90ccff4236ffc83e72de1c43b.jpg', 'EVWPD7325C', '721388343190', 'jcs2A8027SKM7zrg7elF29pvVoLrbb4G', '$2y$13$EASeLQLwAjCkfjbZAjdEVOpzHFfGEkfNv9zR2QFF3STyNVXxJ5eQy', NULL, 'anujji409@gmail.com', 'HUSAINPURA ,JANSATH ,MUZAFFARNARGAR U.P ', '8384841867', '33', '222', 'c9b24bb6-7ddb-42e3-8323-67f95c8eca4d - Copycb9571b90ccff4236ffc83e72de1c43b.jpg', 'c9b24bb6-7ddb-42e3-8323-67f95c8eca4dcb9571b90ccff4236ffc83e72de1c43b.jpg', 'JANSATH', 10, 4, 1556698162, 1556698162),
(37, NULL, 'DOSVLE100037', 'DHARMENDRA', '1000.00', '0.00', '', 'PPPd2038f6e99b7939d96f92bc533ba85da.jpg', 'EVWPD7325C', '721388343190', 'HzXEbCNnrm93Dl1QSi1cvMk30IxzFmIs', '$2y$13$6oTNZOuWZof/LeHJyR.v2eQjUSk9KQHqXVSoxpARwZezKfOYtsuIu', NULL, 'abbidhariwanabhi@gmail.com', 'HUSAINPURA ,JANSATH ,MUZAFFARNARGAR U.P ', '8384841867', '33', '222', 'db361e34-0b50-4125-9355-aaac52ddecd0d2038f6e99b7939d96f92bc533ba85da.jpg', 'e5aeccc1-4459-448e-9492-148b132d5514d2038f6e99b7939d96f92bc533ba85da.jpg', 'JANSATH', 10, 5, 1556700355, 1556702373),
(38, NULL, 'DOSBC100038', 'HARISH KUMAR', NULL, '0.00', '', 'ppa10e306eb91904591c47cb683e495c9a.jpg', 'GWLPK1342A', '890456755409', 'yFQfShdz-Mc9yLn3R8qpJCO3oyrZ7mHL', '$2y$13$oECR0xUlrmvZtQNW6d7vJ.MJQykiinRro7potT/LwbAEVg8APu3XW', NULL, 'hk14042@gmail.com', 'VILLAGE PALI MUST\r\nTEHSIL SAHARANPUR', '9528384965', '33', '227', 'HARa10e306eb91904591c47cb683e495c9a.jpg', '6274d161-71b2-4eab-97dd-abd9de84f9cda10e306eb91904591c47cb683e495c9a.jpg', 'PUWARKA', 10, 4, 1556702469, 1556702469),
(39, NULL, 'DOSVLE100039', 'SUAIB', NULL, '0.00', '', '541e2362-64e6-4865-b64f-971eef4dd952bf0ebadc7bc94968564681cc31f222c3.jpg', 'AAAAA2222D', '555555555555', 'ORGGBX5TonZ4h1tuepd5WqfzmIDo9kg-', '$2y$13$9sLHO67/CIXtRP6L7.GE6.bb58pk1iJ6xwEmZ.3f4beK7ZiQoBeZm', NULL, 'SUAIB222@GMAIL.COM', 'KUTESRA', '9045802055', '33', '222', '541e2362-64e6-4865-b64f-971eef4dd952bf0ebadc7bc94968564681cc31f222c3.jpg', '541e2362-64e6-4865-b64f-971eef4dd952bf0ebadc7bc94968564681cc31f222c3.jpg', 'CHARTHAWAL', 10, 0, 1556900985, 1556900985),
(40, NULL, 'DOSVLE100040', 'SUAIB', NULL, '0.00', '', '541e2362-64e6-4865-b64f-971eef4dd95223e29f766a200b5f78ccffce7fa2ace9.jpg', 'HAAAA5555G', '555555555555', 'TWegkxY-wU5Ouf6uofsAOmmcwnVhJNEu', '$2y$13$vDfgcxqNQ6hKuEHcqiTuJeK9ecv3hsSBFEeYtog4j8OS7B0kaIWHe', NULL, 'SUAIB55@GMAIL.COM', 'MMMMMMMM', '9082545252', '33', '222', '541e2362-64e6-4865-b64f-971eef4dd95223e29f766a200b5f78ccffce7fa2ace9.jpg', '541e2362-64e6-4865-b64f-971eef4dd95223e29f766a200b5f78ccffce7fa2ace9.jpg', 'BUDHANA', 10, 5, 1556901590, 1556901590),
(41, NULL, 'DOSVLE100041', 'bhupendra kumar', NULL, '0.00', '', 'potu747669e17b93158c4e34b4151f233c6f.jpg', 'HGYPK0071G', '519661012268', 'PNASfPM8ZFKAb-sxI7GSIDrd2ss_8AQu', '$2y$13$INcutA3vt9syxiiDZ.p0Yepp/gBMx.7w2yLoH6qwRwSG2TERCrZTa', NULL, 'bkumarmzn1985@gmail.com', 'vill+post-kinouni distt.muzaffarnagar', '9719021470', '33', '222', '706920190504064502imgaadhar.jpg', '88920190504064503imgpan.jpg', 'BAGHRA', 10, 0, 1556950653, 1556950653),
(42, NULL, 'DOSVLE100042', 'Naseem', NULL, '0.00', '', '5bbc311a6bac6_c4472d46-f6ad-4ab1-9b74-c65fd570537b7e6460dfe2b70838b2f99855a8b90a0e.jpg', 'AAAAH8658H', '774367532498', 'Mn9fF6Kuxq_psytn8JYIVUSe8cRphWCG', '$2y$13$NKAA53STXpc1eus1V6Ab0.H4nxKpDauPKl/BNYHaZeCuUIMftyewi', NULL, 'naseemsaifimzn47@gmail.com', 'shahbuddinpur', '7983971050', '33', '222', '5bbc311a6bc8e_9d62296a-4331-4061-8e4f-c635356affb67e6460dfe2b70838b2f99855a8b90a0e.jpg', '5bbc311a6f4fe_e48cb2d7-80b7-4b09-9ba2-71ddfd5210727e6460dfe2b70838b2f99855a8b90a0e.jpg', 'MUZAFFARNAGAR', 10, 0, 1556966760, 1556966760),
(43, NULL, 'DOSVLE100043', 'MUHAMMAD QURBAN', NULL, '0.00', '', 'IMG_24726ae6cdc13a8a4eb0e1b247cf8603b5c0.jpg', 'AANPQ5187H', '550042568766', '4yeq8iMOXY2HBtLe_F1HoHXJUMlT51_v', '$2y$13$s0jGSEnoPBd7zL1/KN4xSeyO2s00RNL4f5fGd1Nr4Vd9iUgWAaPQm', NULL, 'TYAGIQ@GMAIL.COM', 'HOUSE NO 331 MOHALLA IBRAHIM PATTI WARD NO 15  KUTESRA  BLOCK CHARTHAWAL DISST MUZAFFARNAGAR', '9520204778', '33', '222', 'AADHAR6ae6cdc13a8a4eb0e1b247cf8603b5c0.jpg', 'PAN6ae6cdc13a8a4eb0e1b247cf8603b5c0.jpg', 'CHARTHAWAL', 10, 0, 1557033409, 1557033409),
(44, NULL, 'DOSVLE100044', 'SUMIT KUMAR ', NULL, '0.00', '', 'skbec7aed8d1d8711dacf78837bf6d13a66.jpg', 'CZWPK5576Q', '481699553053', 'bO6OZpK9GE5XqqQ-UxDsQBMAd3um8czb', '$2y$13$fMN2wWSDl1Yej1SSPpIp3eTkspJNiJCRvdtVnMJo6.5g0qk5tFw2O', NULL, 'sumitkumar81512@gmail.com', 'VILL PO. KINONI DIST MUZAFFARNAGAR UP', '9808629624', '33', '222', 'IMG_20190506_0001ec7aed8d1d8711dacf78837bf6d13a66.jpg', 'IMG_20190505_162540ec7aed8d1d8711dacf78837bf6d13a66.jpg', 'BAGHARA', 10, 0, 1557147416, 1557147417),
(45, NULL, 'DOSVLE100045', 'ashish', NULL, '0.00', '', '.03644f7a3729460fd199d59c1da78841af.jpg', 'CCIPA5680G', '612304488355', 'P45WSF5njoKAtbkBPZS2BqxNJ4gRH_yO', '$2y$13$G42wbCRA2uWovrVScNbxwOl2DbHZOj08f3Vt4rwswZWqYjWPtE33q', NULL, 'kambojashish744@gmail.com', 'village post khurrampur tehsil behat', '9759649461', '33', '227', 'ashish644f7a3729460fd199d59c1da78841af.jpg', '03644f7a3729460fd199d59c1da78841af.jpg', 'MUZAFFRABAD', 10, 0, 1557900281, 1557900281),
(46, NULL, 'DOSVLE100046', 'ankit kumar', '1000.00', '0.00', '', 'ankit2f1557db8738b7eb86f71957f97964e0.jpg', 'GJRPK6647F', '526943566772', 'HJJzEikPNzPBcTsUCquJbmaeXOLzD-xz', '$2y$13$zifFFarH6/4KjwMxHNMF7eKpMGi.MF2GwxPAplEMIwalmeTlwg7Tu', NULL, 'ankitkashyap9759749576@gmail.com', 'haider nagar jalalpur\r\n104', '9759749576', '33', '222', 'img20190518_171357262f1557db8738b7eb86f71957f97964e0.jpg', 'img20190424_124414172f1557db8738b7eb86f71957f97964e0.jpg', 'BAGHRA', 10, 0, 1558187446, 1558938772),
(47, NULL, 'DOSVLE100047', 'JAVED ALAM', NULL, '0.00', '', 'img20190520_095457269699226eadb94f3f5d318a84dd9eda08.jpg', 'BNUPA1711N', '526565968699', 'qdcH2w_qWktLzokX1eNoI8gIHBnmy_uq', '$2y$13$QxKA4/1awKyas9dVhs/WyeVleMS0gXC08GbfdD31sS7WutN597oMi', NULL, 'javeda648@gmail.com', 'VILLAGE-NAGLA RAI POST-CHARTHAWAL DISST MUZARFFARNAGARR', '7895234527', '33', '222', 'img20190520_095428939699226eadb94f3f5d318a84dd9eda08.jpg', '20181221_0956069699226eadb94f3f5d318a84dd9eda08.jpg', 'CHARTHAWAL', 10, 0, 1558327209, 1558327209),
(48, NULL, 'DOSVLE100048', 'RAVI VERMA', NULL, '0.00', '', 'ravi photo063fc0492e386a9e47ca8b481a578b9c.jpg', 'AETPV1348F', '324293287062', 'ciahXw_Ckk57SYwk2LFKewj9xRoXWiiS', '$2y$13$0WEVQBrOS9Frt4agkc0AVe7elqE1FUj7RL7wd9u.vXZSdDguJeNja', NULL, 'RAVI.VERMA966@GMAIL.COM', 'F-70 B TEHSIL PARISAR NEAR SHIV CHOWK MUZAFFARNAGAR 251002', '9219527501', '33', '222', 'ravi aadhara1063fc0492e386a9e47ca8b481a578b9c.jpg', 'ravi pan card063fc0492e386a9e47ca8b481a578b9c.jpg', 'MUZAFFARNAGAR', 10, 0, 1558962179, 1558962179),
(49, NULL, 'DOSVLE100049', 'Mohit', NULL, '0.00', '', 'IMG-20190510-WA0002012655296484b83b1ee4259ff8fd42fc.jpg', 'EGVPM0077C', '482552959511', 'uErroOXUDXqraKnTkMR9Sm5izfxwlnbI', '$2y$13$Ih5nmSoz1sN7JY4OGnNDdOtmPkvTeNv19M5uH7W.UgqeD7N6IhIOS', NULL, 'mk409990@gmail.com', 'VPO Pachenda kalan muzaffarnagar 251001', '8899936769', '33', '222', 'ADHAR012655296484b83b1ee4259ff8fd42fc.jpg', '20190523_081922012655296484b83b1ee4259ff8fd42fc.jpg', 'MUZAFFARNAGAR', 10, 0, 1559021043, 1559021044),
(50, NULL, 'DOSVLE100050', 'DANISH', NULL, '0.00', '', 'PHOTO870df2de66f68cba4b002632f75caf60.jpg', 'FPMPD5172J', '332664400784', 'POD0bf3fn7n-P5HvIjEJZE9aqVT3bSik', '$2y$13$gCPs/FZ/Pm9znOJSnruCZe9YnXiNosMPCI/GyH7L1VEwd7IrONbnW', NULL, 'DANISHSALMANI821@GMAIL.COM', '108,JATWARAH,NEAR KABRISTAN,JANSATH,MUZAFFARNAGAR 251314', '9719750937', '33', '222', 'AADHAR870df2de66f68cba4b002632f75caf60.jpg', 'PAN CARD870df2de66f68cba4b002632f75caf60.jpg', 'JANSATH', 10, 0, 1559118200, 1559118200),
(51, NULL, 'DOSVLE100051', 'MOHD AARIF', NULL, '0.00', '', 'aarifba2eb72ca7ec0b13a866795a664a8fe3.jpg', 'DAMPA3172A', '576629826309', 'slX2yG0p20jSMfx8WbpFnDtcrRMMCNcz', '$2y$13$c3URfU.rj31qSFOfHXGYAeGWGYPhC8UfUFRr4WNSYZU08S0QqQQ/K', NULL, 'MOAARIF74656@GMAIL.COM', 'JATWADA', '8755571969', '33', '222', 'AARIF copyba2eb72ca7ec0b13a866795a664a8fe3.jpg', 'MOHD copyba2eb72ca7ec0b13a866795a664a8fe3.jpg', 'JANSATH', 10, 0, 1559119638, 1559119638),
(52, NULL, 'DOSVLE100052', 'FARMAN ALI', NULL, '0.00', '', 'PHOTOff536c612c610640a4171d9756216438.jpg', 'CPCPA8422F', '500225511490', 'yjVA7YyhP9ZSsT6wKOZNhRWTrQxtkTrf', '$2y$13$K56w5Mf/Q/eWzQg9WV92a.SsjTzmps968e048EK6XCo1I3J3If3V.', NULL, 'FALI95874@GMAIL.COM', 'SHAMLI ROAD NEAR PNB BANK GOUSHAL MUZAFFARNAGAR 251001', '9568794863', '33', '222', 'ADHA CARDff536c612c610640a4171d9756216438.jpg', 'PAN CARDff536c612c610640a4171d9756216438.jpg', 'MUZAFFARNAGAR', 10, 0, 1559202102, 1559202102),
(53, NULL, 'DOSVLE100053', 'Amit Kumar Sahu', NULL, '0.00', '', '59625496_1294946943989204_7785908016880025600_n4ef07e5da8e079992679f15482dfb7e7.jpg', 'EIJPS9438F', '587500720931', '5EXkUL7ZuarPddg12zN7yjwzIO5Vk_0d', '$2y$13$XVaI0j5l4A.JVCqFOqBK.edeQnJd8ZhAMElHGsj18JjvauiemE4Da', NULL, 'amitkumarviet12211@gmail.com', 'est', '7503212148', '33', '167', 'c5c3ae39-8244-451e-9b38-528deb6314744ef07e5da8e079992679f15482dfb7e7.jpg', 'c5c3ae39-8244-451e-9b38-528deb6314744ef07e5da8e079992679f15482dfb7e7.jpg', 'test', 0, 0, 1572966621, 1572966622);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `router_details`
--
ALTER TABLE `router_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_live_satta`
--
ALTER TABLE `tbl_live_satta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_satta`
--
ALTER TABLE `tbl_satta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_satt_chart`
--
ALTER TABLE `tbl_satt_chart`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `router_details`
--
ALTER TABLE `router_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_live_satta`
--
ALTER TABLE `tbl_live_satta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_satta`
--
ALTER TABLE `tbl_satta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_satt_chart`
--
ALTER TABLE `tbl_satt_chart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
