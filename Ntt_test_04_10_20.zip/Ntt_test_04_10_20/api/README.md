Answers:
Exersie 1:
Question 1 and 2:
files:
1.index.php
2.custom_form.php
3.custom_form.js

please configure db at api\config\config.php
Db shcema is as attached

Question 3:
Please find file: unique_number_gen_cmd.php
php unique_number_gen_cmd.php
it asks integer number

Question 4:
   triangle.php

Excersie 2:-
   Question 1:
  File: server_connection.php
 
  Question 2:
  File: create_rand_zip_file.php
 
  Question 3:
 auto_restart.sh
 cron to schedule:
 # restart Apache if load is higher than 25
 */15 * * * * /usr/sbin/restart_apache_on_high_load.sh >/dev/null 2>&1
 #checks every 15 min
 auto restat server if to much load:
      Question 4:
 Moniter server performance:
 moniter_server_perfromance.php
 
  Question 5:
  CREATE VIEW ROUTER AS
SELECT *
FROM router_details
WHERE 1=1;
    Question 6:
    Please find file: unique_number_gen_cmd.php
php unique_number_gen_cmd.php
it asks integer number
enter no. 10

API SPECS:-
Auth login:
http://localhost/cisco_test/api/auth.php?username=amit&password=amit
response
{'status' : 'success','resp':{"jwt":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpYXQiOjE1OTE1MDgxMzgsImp0aSI6IjcyTXU5cjVGWndFYVQxWHBqeVNNaCs0QzY2M2dvQm9IS0NzNUpHbWlnbk09IiwiaXNzIjoiaHR0cDpcL1wvbG9jYWxob3N0XC9jaXNjb190ZXN0XC9hcGlcLyIsIm5iZiI6MTU5MTUwODE0OCwiZXhwIjoxNTkxNTE1MzQ4LCJkYXRhIjp7ImlkIjoiMSIsIm5hbWUiOiJhbWl0In19.aOrfQwe7NAuLKotHe3SLfr7-1Vxwj8zwYKsSB-8IPZPBCPKc4HgwhdXWiYf5rOlNXSOa00adfTjIffCwrYfqLA"}}


2. listing of api:
a.
http://localhost/cisco_test/api/list.php
?tokVal=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpYXQiOjE1OTE1MDgxMzgsImp0aSI6IjcyTXU5cjVGWndFYVQxWHBqeVNNaCs0QzY2M2dvQm9IS0NzNUpHbWlnbk09IiwiaXNzIjoiaHR0cDpcL1wvbG9jYWxob3N0XC9jaXNjb190ZXN0XC9hcGlcLyIsIm5iZiI6MTU5MTUwODE0OCwiZXhwIjoxNTkxNTE1MzQ4LCJkYXRhIjp7ImlkIjoiMSIsIm5hbWUiOiJhbWl0In19.aOrfQwe7NAuLKotHe3SLfr7-1Vxwj8zwYKsSB-8IPZPBCPKc4HgwhdXWiYf5rOlNXSOa00adfTjIffCwrYfqLA
&SapId=b6mDQNvt8hoIqUziAMnT

b. search between ip range
http://localhost/cisco_test/api/list.php
?tokVal=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpYXQiOjE1OTE1MDgxMzgsImp0aSI6IjcyTXU5cjVGWndFYVQxWHBqeVNNaCs0QzY2M2dvQm9IS0NzNUpHbWlnbk09IiwiaXNzIjoiaHR0cDpcL1wvbG9jYWxob3N0XC9jaXNjb190ZXN0XC9hcGlcLyIsIm5iZiI6MTU5MTUwODE0OCwiZXhwIjoxNTkxNTE1MzQ4LCJkYXRhIjp7ImlkIjoiMSIsIm5hbWUiOiJhbWl0In19.aOrfQwe7NAuLKotHe3SLfr7-1Vxwj8zwYKsSB-8IPZPBCPKc4HgwhdXWiYf5rOlNXSOa00adfTjIffCwrYfqLA
&ipStart=10.22.99.129
&ipEnd=10.22.99.255


response:
{"message":"ok","data":[{"id":"5"
,"SapId":"b6mDQNvt8hoIqUziAMnT"
,"hostname":"www.pO14GrbDSqWK87YtZdky.com",
"ip_addr":"122.84.19.100","loopback":"235.24.130.25","macaddress":"20:62:ad:18:10:a8","date_created":"2020-06-07 07:23:58","deleted":"0"}]}

3. create:

POST /cisco_test/api/create.php?tokVal=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpYXQiOjE1OTE1MDg2MDUsImp0aSI6InpmM0N6TWRNVmUwVys3OFdHVEVMUHZIczBYVWcrTkdnYWlqaGJMZFwvNWZVPSIsImlzcyI6Imh0dHA6XC9cL2xvY2FsaG9zdFwvY2lzY29fdGVzdFwvYXBpXC8iLCJuYmYiOjE1OTE1MDg2MTUsImV4cCI6MTU5MTUxNTgxNSwiZGF0YSI6eyJpZCI6IjEiLCJuYW1lIjoiYW1pdCJ9fQ.ksgc-zzV8U_DUHR0AwBYRN1_bf9aUfMfCCZpIwo2koNJqQUg6sGIJq_VIcLlXB0uUl3-3ViCXlFKpo3ZGwGzFw
&method=create&
SapId=sdfsdfdsfsdfsdfsdfdsfsdfsdfsdfsdfdsfds&
hostname=www.google.com111&
macaddress=www.google.com111&loopback=192.168.168.11 HTTP/1.1
Host: localhost
Cache-Control: no-cache

3. update:

POST /cisco_test/api/create.php?tokVal=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpYXQiOjE1OTE1MDg2MDUsImp0aSI6InpmM0N6TWRNVmUwVys3OFdHVEVMUHZIczBYVWcrTkdnYWlqaGJMZFwvNWZVPSIsImlzcyI6Imh0dHA6XC9cL2xvY2FsaG9zdFwvY2lzY29fdGVzdFwvYXBpXC8iLCJuYmYiOjE1OTE1MDg2MTUsImV4cCI6MTU5MTUxNTgxNSwiZGF0YSI6eyJpZCI6IjEiLCJuYW1lIjoiYW1pdCJ9fQ.ksgc-zzV8U_DUHR0AwBYRN1_bf9aUfMfCCZpIwo2koNJqQUg6sGIJq_VIcLlXB0uUl3-3ViCXlFKpo3ZGwGzFw
&method=update&
SapId=sdfsdfdsfsdfsdfsdfdsfsdfsdfsdfsdfdsfds&
hostname=www.google.com111&
macaddress=www.google.com111&loopback=192.168.168.11
 HTTP/1.1
Host: localhost
Cache-Control: no-cache

4. delete
GET /cisco_test/api/delete.php?tokVal=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpYXQiOjE1OTE1MDg2MDUsImp0aSI6InpmM0N6TWRNVmUwVys3OFdHVEVMUHZIczBYVWcrTkdnYWlqaGJMZFwvNWZVPSIsImlzcyI6Imh0dHA6XC9cL2xvY2FsaG9zdFwvY2lzY29fdGVzdFwvYXBpXC8iLCJuYmYiOjE1OTE1MDg2MTUsImV4cCI6MTU5MTUxNTgxNSwiZGF0YSI6eyJpZCI6IjEiLCJuYW1lIjoiYW1pdCJ9fQ.ksgc-zzV8U_DUHR0AwBYRN1_bf9aUfMfCCZpIwo2koNJqQUg6sGIJq_VIcLlXB0uUl3-3ViCXlFKpo3ZGwGzFw&loopback=192.168.12.12 HTTP/1.1
Host: localhost
Cache-Control: no-cache
 
  

Regards,
Vinod kumar	
Mob:8506800799.
Email:studentvinod.87@gmail.com
