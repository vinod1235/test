<?php
error_reporting(0);
include_once './config/config.php';
require_once('vendor/autoload.php');
use \Firebase\JWT\JWT; 

header("Access-Control-Allow-Origin: * ");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$databaseService = new DatabaseService();
$conn = $databaseService->getConnection();

define('SECRET_KEY','Your-Secret-Key');  /// secret key can be a random string and keep in secret from anyone
define('ALGORITHM','HS512');   // Algorithm used to sign the token, see

$data = $_REQUEST;


if(isset($data)){

            try {
               $secretKey = base64_decode(SECRET_KEY); 
               $DecodedDataArray = JWT::decode($_REQUEST['tokVal'], $secretKey, array(ALGORITHM));
               $sap_id=$data['SapId'];
			    $host_name=$data['hostname'];
			    $loopback=$data['loopback'];
				$mac_address=$data['macaddress'];
				$ip_addr=$data['ip_addr'];
				$created_date=date('Y-m-d');
 if(isset($sap_id)&&isset($host_name)&&isset($loopback)&&isset($mac_address)){
	if(!$databaseService->checkunique('hostname',$host_name)){	
		http_response_code(400);
	 echo json_encode(array("message" => "Host name already exist."));
	exit();
	}
	
	if(!$databaseService->checkunique('loopback',$loopback)){	
	   http_response_code(400);
	   echo json_encode(array("message" => "Loop Back already exist."));
	   exit();
	   }else if(!filter_var($loopback, FILTER_VALIDATE_IP)){
	      http_response_code(400);
	   echo json_encode(array("message" => "Invalid Loop back."));
	   exit();
	 	}
	   
	if($_REQUEST['method']=='create'){
	 
	 $sql = "INSERT INTO `router_details` (`id`, `SapId`, `hostname`,`loopback` ,`macaddress`, `date_created`,`deleted`) VALUES (?,?,?,?,?,?,?)";
     $stmt= $conn->prepare($sql);
     $excuted=$stmt->execute([NULL,$sap_id, $host_name, $loopback,$mac_address,$created_date,0]);
     if(isset($excuted)){
    http_response_code(200);
    echo json_encode(array("message" => "Router was successfully registered."));
	exit();
     }
	}else if($_REQUEST['method']=='update'){
		 $sql = "UPDATE `router_details` 
	         SET `SapId`='{$sap_id}',`hostname`='{$host_name}',`macaddress`='{$mac_address}' where loopback='{$loopback}'";
	  $stmt= $conn->prepare($sql);
	  $excuted= $stmt->execute();
	  http_response_code(200);
	  echo json_encode(array("message" => "Router was successfully updated."));
      exit();
	}
 }else{
	  http_response_code(400);
	   echo json_encode(array("message" => "please enter all fields."));
	   exit();
 }


               } catch (Exception $e) {


                echo "{'status' : 'fail' ,'msg':'Unauthorized'}";die();


               }


}else{
    http_response_code(400);

    echo json_encode(array("message" => "Unable to register the router."));
}
?>