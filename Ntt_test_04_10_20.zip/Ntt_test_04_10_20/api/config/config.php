<?php
// used to get mysql database connection
class DatabaseService{

    private $db_host = "localhost";
    private $db_name = "satta";
    private $db_user = "root";
    private $db_password = "";
    private $connection;
    
	public function getConnection(){

        $this->connection = null;

        try{
            $this->connection = new PDO("mysql:host=" . $this->db_host . ";dbname=" . $this->db_name, $this->db_user, $this->db_password);
        }catch(PDOException $exception){
            echo "Connection failed: " . $exception->getMessage();
        }

        return $this->connection;
    }
	
	
	public function checkunique($key,$value){
		$conn=$this->getConnection();
		$sql = "select * from  router_details  WHERE  ".$key."='".$value."'";
        $stmt = $conn->prepare( $sql );
        $stmt->execute();
        $num = $stmt->rowCount();
		if( $num>0){
			return false;
		}else{	   
	   return true;
		}
	}
	
	 public function random_strings($length_of_string) 
		{ 
			// String of all alphanumeric character 
			$str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; 
		  
			// Shufle the $str_result and returns substring 
			// of specified length 
			return substr(str_shuffle($str_result), 0, $length_of_string); 
		}
public function isValidIP($str)
{
	$valid = preg_match('/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\z/', $str);

	//if ( false === filter_var($str, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE) )
   if(!$valid) 
   {
       return false;
   }
   else
   {
       return true;
   }

}
		
}
?>
