<?php

class TokenAuth {
 public function require_auth() {
	$AUTH_USER = 'admin';
	$AUTH_PASS = 'admin';
	//need to implement jwt token
	header('Cache-Control: no-cache, must-revalidate, max-age=0');
	$data = json_decode(file_get_contents("php://input"));
	if($data->token='312312312312312312'){
		return true;
	}else{
		 http_response_code(400);
		echo json_encode(array("message" => "unable to delelte record"));
   }
}
}
