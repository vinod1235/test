<?php
error_reporting(0);
require_once('vendor/autoload.php');
use \Firebase\JWT\JWT; 
include_once './config/config.php';
header("Access-Control-Allow-Origin: * ");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
define('SECRET_KEY','Your-Secret-Key');  /// secret key can be a random string and keep in secret from anyone
define('ALGORITHM','HS512');   // Algorithm used to sign the token, see


if(isset($_REQUEST)){

$conn = null;
$databaseService = new DatabaseService();
$conn = $databaseService->getConnection();

               try {
     $secretKey = base64_decode(SECRET_KEY); 
    $DecodedDataArray = JWT::decode($_REQUEST['tokVal'], $secretKey, array(ALGORITHM));
    $sap_id=$_REQUEST['SapId'];
	$host_name=$_REQUEST['loopback'];
	$ipStart=$_REQUEST['ipStart'];
	$ipEnd=$_REQUEST['ipEnd'];
	
	
        $query='';
		if($query==''){
			$query=' 1=1';
		}
		if(isset($sap_id) && ($sap_id !='')){
			$query.=' and SapId LIKE "%'.$sap_id.'%"';
            $sql = "select * from  router_details  WHERE  ".$query;
	      }
		if(isset($ipStart) &&($ipEnd !='')){
		$sql="SELECT * FROM router_details WHERE (INET_ATON(loopback) BETWEEN INET_ATON('".$ipStart."') AND INET_ATON('".$ipEnd."'))";
       }
  	$stmt = $conn->prepare( $sql );
	$stmt->execute();
	$num = $stmt->rowCount();
    $final_array=array();
	if($num > 0){
		while($data_11 = $stmt->fetch(PDO::FETCH_ASSOC)){
			$final_array[]=$data_11;
		}
	}
   
if(!empty($final_array)){
    http_response_code(200);
    echo json_encode(array("message" => "ok",'data'=>$final_array));
    
	}else{
    http_response_code(400);
    echo json_encode(array("message" => "No record Found"));
}
			   }catch (Exception $e) {


                echo "{'status' : 'fail' ,'msg':'Unauthorized'}";die();


               }
	
}else{
    http_response_code(400);
    echo json_encode(array("message" => "No record Found"));
	
	
}
?>