<?php
include_once './config/config.php';
include_once './config/checktoken.php';
require_once('vendor/autoload.php');
use \Firebase\JWT\JWT; 
header("Access-Control-Allow-Origin: * ");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
define('SECRET_KEY','Your-Secret-Key');  /// secret key can be a random string and keep in secret from anyone
define('ALGORITHM','HS512');   // Algorithm used to sign the token, see

$conn = null;
$databaseService = new DatabaseService();
$conn = $databaseService->getConnection();
$data = $_REQUEST;
if(isset($data)){
      try {
		$secretKey = base64_decode(SECRET_KEY); 
	    $DecodedDataArray = JWT::decode($_REQUEST['tokVal'], $secretKey, array(ALGORITHM));
	    $host_name=$data['loopback'];
	    $sql="select * FROM router_details WHERE loopback LIKE '%".$host_name."%'";
        $stmt = $conn->prepare( $sql );
	    $stmt->execute();
	    $num = $stmt->rowCount();
     if($num >0){
	   
	 if($host_name){
		$sql="delete FROM router_details WHERE loopback='".$host_name."'";
        $stmt = $conn->prepare( $sql );
	    if($stmt->execute()){
	    http_response_code(200);
       echo json_encode(array("message" => "Router was successfully deleted."));
		}
	 }
	}else{
	http_response_code(400);
    echo json_encode(array("message" => "unable to delete record"));	
	}
			   }
   catch (Exception $e) {
	echo "{'status' : 'fail' ,'msg':'Unauthorized'}";die();
 }
}

?>