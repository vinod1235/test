<?php
include_once './config/config.php';
include_once './config/checktoken.php';
require_once('vendor/autoload.php');
use \Firebase\JWT\JWT; 
header("Access-Control-Allow-Origin: * ");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

define('SECRET_KEY','Your-Secret-Key');  /// secret key can be a random string and keep in secret from anyone
define('ALGORITHM','HS512');   // Algorithm used to sign the token, see

$databaseService = new DatabaseService();
$conn = $databaseService->getConnection();
$data = $_REQUEST;
$action='authenticate';

if ( $action == 'authenticate' ){


               try {


               $secretKey = base64_decode(SECRET_KEY); 


               $DecodedDataArray = JWT::decode($_REQUEST['tokVal'], $secretKey, array(ALGORITHM));

 


               echo  "{'status' : 'success' ,'data':".json_encode($DecodedDataArray)." }";die();

 


               } catch (Exception $e) {


                echo "{'status' : 'fail' ,'msg':'Unauthorized'}";die();


               }


   }

?>