<?php
error_reporting(0);
include_once './config/config.php';
include_once './config/checktoken.php';
require_once('vendor/autoload.php');
use \Firebase\JWT\JWT; 
header("Access-Control-Allow-Origin: * ");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

define('SECRET_KEY','Your-Secret-Key');  /// secret key can be a random string and keep in secret from anyone
define('ALGORITHM','HS512');   // Algorithm used to sign the token, see

$databaseService = new DatabaseService();
$conn = $databaseService->getConnection();
$data = $_REQUEST;

if(!(isset($data['username']) &&$data['password'])){
	
http_response_code(400);
    echo json_encode(array("message" => "Please enter valid username and passowrd"));	
		
}
$username=$data['username'];
$password=$data['password'];


if ($username && $password ) {
	 $statement = $conn->prepare("select * from login where username = :name" );
	 $statement->execute(array(':name' => $username));
	 $row = $statement->fetchAll(PDO::FETCH_ASSOC);
	 $hashAndSalt = md5($password);
	 
	 
		if(count($row)>0 && ($row[0]['password']==	$hashAndSalt))
		{           $tokenId    = base64_encode(mcrypt_create_iv(32));
                    $issuedAt   = time();
                    $notBefore  = $issuedAt + 10;  //Adding 10 seconds


                    $expire     = $notBefore + 7200; // Adding 60 seconds
                    $serverName = 'http://localhost/cisco_test/api/'; /// set your domain name 
                      /*

                     * Create the token as an array

                     */


                    $data = [


                        'iat'  => $issuedAt,         // Issued at: time when the token was generated


                        'jti'  => $tokenId,          // Json Token Id: an unique identifier for the token


                        'iss'  => $serverName,       // Issuer


                        'nbf'  => $notBefore,        // Not before


                        'exp'  => $expire,           // Expire


                        'data' => [                  // Data related to the logged user you can set your required data


				    'id'   => $row[0]['id'], // id from the users table
				     'name' => $row[0]['username'], //  name
                                  ]
                    ];
                  $secretKey = base64_decode(SECRET_KEY);
                  /// Here we will transform this array into JWT:
                  $jwt = JWT::encode(
                            $data, //Data to be encoded in the JWT
                            $secretKey, // The signing key
                             ALGORITHM 
                           ); 
                 $unencodedArray = ['jwt' => $jwt];
                  echo  "{'status' : 'success','resp':".json_encode($unencodedArray)."}";
           } else {

                  echo  "{'status' : 'error','msg':'Invalid email or passowrd'}";
                  }
     }    

	 ?>