<?php


$socket = fsockopen("192.168.52.1", 8000);

if(!$socket)return;
stream_set_blocking($socket, 0);
stream_set_blocking(STDIN, 0);
//get user input
echo 'Please Enter number to generate number:';
$handle=fopen('php://stdin','r');
$line=fgets($handle);
$n=(int)$line;
do {
// create files
for($i=0;$i<$n;$i++){
$myfile = fopen("newfile_".$i.".txt", "w") or die("Unable to open file!");
$txt = "amit testing\n";
fwrite($myfile, $txt);
$txt = "amit testing\n";
fwrite($myfile, $txt);
fclose($myfile);

}

$zip = new ZipArchive();
$filename = "./test112.zip";


if ($zip->open($filename, ZipArchive::CREATE)!==TRUE) {
    exit("cannot open <$filename>\n");
}

for($i=0;$i<$n;$i++){
$zip->addFromString("newfile_".$i.".txt" . time(), "#1 This is a test string added as testfilephp.txt.\n");
}
echo "numfiles: " . $zip->numFiles . "\n";
echo "status:" . $zip->status . "\n";
$zip->close();
///make  zip
} while(true);


///process download

$filepath="./test112.zip";
        if(file_exists($filepath)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="'.basename($filepath).'"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filepath));
            flush(); // Flush system output buffer
            readfile($filepath);
            die();
        } else {
            http_response_code(404);
	        die();
        }




?>