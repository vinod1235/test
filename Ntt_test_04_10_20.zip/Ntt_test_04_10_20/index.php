<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
</head>
<body>
<br/><br/><br/><br/>
<h2>Search:</h2>
<br/>
<label>SAP ID : <label><input type="text" style="margin-Left:20px;" name="sap_id" size="30" onkeyup="showResult(this)">
<label>Host Name : <label><input type="text" style="margin-left:15px;" name="host_name" size="30" onkeyup="showResult(this)">
<br/>
<br/>
<label>Loop Back : <label><input type="text" name="loop_back" size="30" onkeyup="showResult(this)">
<label>MAC address : <label><input type="text" name="mac_addr" size="30" onkeyup="showResult(this)">
<br/><br/><br/>
<div class="panel panel-default tab-panel-0"  style="display: block;">
<div class="panel-heading panel-heading-collapse">
<a class="collapsed"  id="custom_subpanel_audit_contact" role="button" data-toggle="collapse-edit" aria-expanded="false">
<div class="col-xs-10 col-sm-11 col-md-11">
Router Details
</div>
</a>
</div>
<div class="panel-body panel-expanded expanded panelContainer hide" id="detailpanel_99" style="display:block;" >
             <div class="tab-content"><div class="input_fields_wrap">
			<button id="add_field_button" class="button primary"><b>Create Router Detail</b></button>
			<button id="save_audit_contacts" class="button primary" style="display:none;"><b>Save Router Detail</b></button>
			<button id="cancel_audit_contacts" class="button primary"  style="display:none;"><b>Cancel</b></button>

     </div><div><div class="list-view-rounded-corners" style="overflow: hidden !important;">
		<table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>SAP ID</th>
                <th>Host Name</th>
                <th>Loop Back</th>
                <th>MAC address</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="livesearch">

<?php
  require_once "./api/config/config.php";
  $databaseService = new DatabaseService();
  $conn = $databaseService->getConnection();
  $audit_record_query = "SELECT * FROM 	router_details where deleted=0   order by id asc";
  $stmt = $conn->prepare( $audit_record_query );
  $stmt->execute();
  $num = $stmt->rowCount();
if($num > 0){
 
  $i=0;
  $audit_records='';
 while ( $row = $stmt->fetch(PDO::FETCH_ASSOC)) { 
         $audit_records.='<tr height="20" id="audit_record_' . $row['id'] . '">
                <td scope="row" align="left" valign="top" type="SapId" field="SapId" class=" "><b>
				'.$row['SapId'].'</b></td>
                 <td align="left" valign="top" type="enum" field="hostname" class="hidden-xs ">
                    '.$row['hostname'].'</td>
                <td align="left" valign="top" type="loopback" field="loopback" class="hidden-xs  loopback">
                '.$row['loopback'].'</td>
                <td align="left" valign="top" type="macaddress" field="macaddress" class="hidden-xs  macaddress">
                '.$row['macaddress'].'</td>
			    <td align="left" class="">
				<button class="delete" data-id="' . $row['id'] . '" style="background:#378cbe;color:#f5f5f5;height:30px;"><b>Delete</b></button>
				<button class="edit" data-id="' . $row['id'] . '" style="background:#378cbe;color:#f5f5f5;height:30px;padding-top:4px;"><b>Edit</b></button>
				</td>			</tr>';
  }
      	
?>

            

<?php
 $audit_html='';		
   $audit_html.=$audit_records;
   $audit_html.='</tbody>
    </table>
</div>
<div class="clear"></div>
<div class="clear"></div>
</div>     
</div>
</div></div>';		
echo   $audit_html;
}
?>

  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
  
   <script src="custom_form.js"></script>
 
  <script>
  $(function(){
    $("#example").dataTable();
  })
  </script>

</body>
</html>
