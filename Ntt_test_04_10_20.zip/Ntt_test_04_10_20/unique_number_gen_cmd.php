<?php
echo 'Please Enter number to generate number:';
$handle=fopen('php://stdin','r');
$line=fgets($handle);
$n=(int)$line;


if(is_int($n)){
  require_once "./api/config/config.php";
    $databaseService = new DatabaseService();
    $conn = $databaseService->getConnection();
	$finalarr=array();
	for($i=1;$i<=$n;$i++){
		$sap_id=$databaseService->random_strings(20);
		$host_name='www.'.$databaseService->random_strings(20).'.com';
		$created_date=date('Y-m-d h:i:s');
	    $mac_address=implode(':', str_split(str_pad(base_convert(mt_rand(0, 0xffffff), 10, 16) . base_convert(mt_rand(0, 0xffffff), 10, 16), 12), 2));
		$randIP = "".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255);
		$loopback = "".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255);


	if($databaseService->checkunique('SapId',$sap_id) && $databaseService->checkunique('hostname',$host_name)&& $databaseService->checkunique('loopback',$loopback)){
		$sql = "INSERT INTO `router_details` (`id`, `SapId`, `hostname`,`loopback` ,`macaddress`, `date_created`, `deleted`,`ip_addr`) VALUES (?,?,?,?,?,?,?,?)";
		$stmt= $conn->prepare($sql);
	    $stmt->execute([NULL,$sap_id, $host_name, $loopback,$mac_address,$created_date,0,$randIP]);
	}
	}
		echo json_encode(array('msg'=>"No. of Random record created:".$n,'response'=>'success'),TRUE);
}else{
	echo json_encode(array('msg'=>"Please Enter valid Integer",'response'=>'fail'),TRUE);
}
?>