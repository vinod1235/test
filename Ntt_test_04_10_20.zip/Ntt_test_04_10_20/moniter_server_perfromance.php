1.check disk usage
 df -h 
displays all the node is being consumed

2.which process is consuming more resouce.
ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem | head

to kill a pid:
kill -9 pid (to kill pid)


relaod the apache
3. serivice apache2 reload;