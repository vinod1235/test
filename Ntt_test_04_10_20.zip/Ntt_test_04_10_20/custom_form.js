function checkloopback(id){
	var statusc=0;
	$.ajax({
   		url:'router_details.php',
          type: 'GET',
  	  data: {
    	'checkloopback': 'check',
    	'loopback': id,
      },
      success: function(response){
		
		if(response=='true'){
			  statusc=1;
		  }else{
		  statusc=0;
		  }
		  return statusc;
	  }
  	});

}

function showResult(str) {
	var name=str.name;
    var value=str.value;
  
  if (str.length==0) {
    document.getElementById("livesearch").innerHTML="";
    document.getElementById("livesearch").style.border="0px";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("livesearch").innerHTML=this.responseText;
      document.getElementById("livesearch").style.border="1px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","router_details.php?action=search_listing&name="+name+"&value="+value,true);
  xmlhttp.send();
}
function hidediv(hide){
 $(hide).parent().parent().fadeOut();
	
}









function custom_alert(msg){ 
  if($(".tab-content_2").find("#final_error_2").length == 0){
     $(".tab-content_2").prepend('<div id="final_error_2"></div>');
  }
  $("#final_error_2").html("");
  $("#final_error_2").prepend('<div style="color:red;">'+msg+'<span"><a href="javascript:void(0);" onclick="hidediv(this);" id="close_error_msg" ><img alt="Close" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAMAAACelLz8AAAAY1BMVEVHcEwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADIAbxiAAAAIHRSTlMAICNOCrzf+eMk4k8fCRG051C7+NnYHkyzvRLB2sC13qveMz0AAACgSURBVCjPvdLZEoMgDAVQpKgEqdpq9y3//5XVhhCU6WObp8gZlptRqX/X9nwH7k036kT2iDaYKaWfqsOprGZBdC3TiGwkWBdMRUUG88mz7OQysJ8l9yDZpE8M+7I9S6ubdTS2XJS5EfWQSckHWvgmazMXuqfPjGfQxOyRnjFpyG7jDA8yA7LBM/mX5PHVclLayZd2wyl9Yuulvx5/9C+9AXyrFPqi9yC+AAAAAElFTkSuQmCC"></a></span></div>')
}
$(document).ready(function() {

	$("#custom_subpanel_audit_contact_detail").click(function(e){
        var x = document.getElementById("detailpanel_99");
    if($(this).hasClass("collapsed")){
	 $(this).removeClass("collapsed");
         $("#detailpanel_99").removeClass("hide");
  	 x.style.display = "block";
 }else{
         $(this).addClass("collapsed");
         $("#detailpanel_99").addClass("hide");
         x.style.display = "none";
	  
  }
});
	


	
	var max_fields      = 10; //maximum input boxes allowed
	var wrapper   		= $(".input_fields_wrap"); //Fields wrapper
	var add_button      = $("#add_field_button"); //Add button ID
	var save_button      = $("#save_audit_contacts"); //Add button ID


	var x = 1; //initlal text box count
	
		$(save_button).click(function(e){ //on add input button click
	      e.preventDefault();
	      	var id='';
		if($("input[name='audit_id']").length){
	    	var id=  $("input[name='audit_id']").val();
	    	}
		var sap_id = $("input[name='sap_id[]']").map(function(){return $(this).val();}).get();
	    var sap_id_attr = $("input[name='sap_id[]']").attr('value');
		var host_name = $("input[name='host_name[]']").map(function(){return $(this).val();}).get();
        var loop_back = $("input[name='loop_back[]']").map(function(){return $(this).val();}).get();
        var mac_address = $("input[name='mac_address[]']").map(function(){return $(this).val();}).get();
        var error=1;
		var msg1="Please Enter SAP ID";
		var msg2="Please Enter Host Name";
		var msg3="Please Enter Loop Back";
		var msg4="Please Enter MAC Address";
		var msg5="Please Enter Audit Date";
		var msg6="Please create a account then add Audit Contact";
		var account_id=$("input[name='record']").val();
		var sap_id=$("input[name='sap_id[]']").val();
        var save_type=$("input[name='save_type']").val();
        var loopregex=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\z/;	
		
	if(sap_id==''){ 
            custom_alert(msg1);
			error=0;
			
		}else if(sap_id.length<18){
			var msg1='SAP ID :Minimum lenght is 18 alhpanumeric charecters';
		    custom_alert(msg1);
			error=0;
			
		} 
			else if(host_name == '')
		{ 
			custom_alert(msg2);
			error=0;
			
		}

	else if(loop_back == '')
		{ 
	    alert(loop_back);
	custom_alert(msg3);
			error=0;
			
		}
		    // else       if (String(loopregex).match(loop_back) == false) {
        else if(loop_back){
			const octet = '(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]?|0)';
            const regex = new RegExp(`^${octet}\\.${octet}\\.${octet}\\.${octet}$`);
            if( regex.test(loop_back)==false){

			var msg1='Invalid Loop Back format';
		    custom_alert(msg1);
			error=0;
			}
		} 
		else if(mac_address == '')
		{ 
	        custom_alert(msg4);
			error=0;
			
		}
		 
		
	if(error==1){
		
    $.ajax({
	    url:'router_details.php',
	    type: 'POST',
      data: {
        'id': id,
        'type': save_type,
        'sap_id': sap_id,
		'account_id': account_id,
        'host_name': host_name,
        'loop_back': loop_back,
        'mac_address': mac_address,
       },
      success: function(response){
		  
		  try {
     var res=JSON.parse(response);
	if(res.sucess==false){
			 custom_alert(res.msg); 
		  }
	} catch (e) {
    $("input[name='sap_id[]']").val('');
        $("input[name='host_name[]']").val('');
        $("input[name='loop_back[]']").val('');
        $("input[name='mac_address[]']").val('');
		$("#save_audit_contacts,#cancel_audit_contacts").fadeOut();
		$("#create_audit_form").remove();
	        $("#add_field_button").fadeIn();
			
	    if(id==''){
		alert("Record saved successfully");
		$('#audit_contacts_table tbody').append(response);
		}else{
		alert("Record updated successfully");
		$('#audit_record_'+id).replaceWith(response);
			
		}
		}
	  }
    });
	}
	});


      $('#cancel_audit_contacts').click(function(e){
	$("#create_audit_form").remove();
        $("#save_audit_contacts,#cancel_audit_contacts").fadeOut();
	$("#add_field_button").fadeIn();
			
});	

	$(add_button).click(function(e){ //on add input button click
		e.preventDefault();
		$("#create_audit_form,#save_audit_contacts,#cancel_audit_contacts").fadeIn();
		if(x < max_fields){ //max input box allowed
		    save_button.show();
			add_button.hide();
			y=1; //text box increment
			if(y==1){
            $(wrapper).append('<div style="height:300px;" id="create_audit_form">'
							+ '<span><b>Router Detail </b></span>'
							+ '<div class="tab-content_2"></div>'
							+'<div class="clear"></div>'
							+ '<div class="col-xs-12 col-sm-6 edit-view-row-item">'
							+'<div class="col-xs-12 col-sm-4 label" >SAP ID:</div>'
							+'<div class="col-xs-12 col-sm-8 edit-view-field " type="varchar" field="sap_id">'
							+'<input type="text" name="sap_id[]" class="sap_id"  minlength="18" style="width:236px;" value="" title="">'
							+' <input type="hidden" name="save_type" id="save" value="save" ></div>'
							+'</div>'
							+'<div class="col-xs-12 col-sm-6 edit-view-row-item">'
							+'<div class="col-xs-12 col-sm-4 label" >Host Name:</div>'
							+'<div class="col-xs-12 col-sm-8 edit-view-field " type="varchar" field="host_name">'
							+'<input type="text" name="host_name[]" class="host_name" minlength="14" maxlength="200" style="width:236px;"	 value="" title="Host Name">'
							+'</div>'
							+'</div>'
							+'<div class="clear"></div>'
							+'<div class="col-xs-12 col-sm-6 edit-view-row-item">'
							+'<div class="col-xs-12 col-sm-4 label" data-label="LBL_host_name">Loop Back:</div>'
							+'<div class="col-xs-12 col-sm-8 edit-view-field " type="varchar" field="loop_back">'
							+'<input type="text" name="loop_back[]" class="loop_back" size="30" maxlength="200" value="" title="Loop Back">'
							+'</div>'
							+'</div>'
							+'<div class="col-xs-12 col-sm-6 edit-view-row-item">'
							+'<div class="col-xs-12 col-sm-4 label" data-label="LBL_mac_address">MAC Address:</div>'
							+'<div class="col-xs-12 col-sm-8 edit-view-field " type="varchar" field="mac_address">'
							+'<input type="text" name="mac_address[]" class="mac_address" size="30" maxlength="20" value="" title="Mac Address"></div>'
							+'</div>'
							+'<br/><br/>'
							+'</div>'
							+'</div>'
							+'</div>'); 
							}
		}
	});
	$(wrapper).on("click",".remove_field", function(e){ //user click on remove text
		e.preventDefault(); $(this).parent('div').parent('div').remove(); x--;
	});
	//new crud operation start
	  // save comment to database
  // delete from database
  $(document).on('click', '.delete', function(){
  	var id = $(this).data('id');
  	$clicked_btn = $(this);
	var cornfirm_box=confirm("Are you Sure?");
	if(cornfirm_box){
  	$.ajax({
   	 // url: 'server.php',
		url:'router_details.php',
          type: 'GET',
  	  data: {
    	'delete': 1,
    	'id': id,
      },
      success: function(response){
		$("#audit_record_"+id).hide();
      }
  	});
	}
  });
 /* $(document).on('click', '.edit', function(){
  	var id = $(this).data('id');
  	$clicked_btn = $(this);
	$.ajax({
   	 // url: 'server.php',
		url:'router_details.php',
          type: 'GET',
  	  data: {
    	'edit': 1,
    	'id': id,
      },
      success: function(response){
	$(".input_fields_wrap").append(response);
      }
  	});
 });
 */

  $(document).on('click', '.edit', function(){
  	var id = $(this).data('id');
  	$clicked_btn = $(this);
	$.ajax({
   	 // url: 'server.php',
		url:'router_details.php',
          type: 'GET',
  	  data: {
    	'edit': 1,
    	'id': id,
      },
      success: function(response){
		  if($('#create_audit_form').length>0){
			  $('#create_audit_form').remove();
			  $(".input_fields_wrap").append(response);
			  $("#save_audit_contacts").show();
			  $("#add_field_button").hide();
			}else{
	   $(".input_fields_wrap").append(response);
	   $("#save_audit_contacts").show();
       $("#add_field_button").hide();
		  }
	  }
  	});
 });

 $(document).on('click','#custom_subpanel_audit_contact',function(e){
    setTimeout(function(){
	 var x = document.getElementById("detailpanel_99");
    if($(this).hasClass("collapsed")){
         $(this).removeClass("collapsed");
       //  $("#detailpanel_99").removeClass("hide");
     if($(this).hasClass("hide")){
         $("#detailpanel_99").removeClass("hide");
		 }
	   // x.style.display = "block";
 }else{
         $(this).addClass("collapsed");
	 if(!$(this).hasClass("hide")){
         $("#detailpanel_99").addClass("hide");
		 }
        // $("#detailpanel_99").addClass("hide");
         //x.style.display = "none";

  }
  },100);
  
  
});
       

});
